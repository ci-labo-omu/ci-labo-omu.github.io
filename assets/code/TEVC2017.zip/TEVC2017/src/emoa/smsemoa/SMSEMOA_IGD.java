package emoa.smsemoa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import core.Algorithm;
import core.Operator;
import core.Problem;
import core.Solution;
import utils.PseudoRandomGenerator;
import utils.indicator.InvertedGenerationalDistance;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class SMSEMOA_IGD extends Algorithm{

	int numberOfIterations_;

	int populationSize_;

	ArrayList<Solution> solutionSet_;

	ArrayList<Solution> offspringSet_;

	ArrayList<Solution> mergeSet_;

	Operator crossover_;
	Operator mutation_;
	Operator selection_;

	ArrayList<ArrayList<Double>> lambda;

	String fileName_;

	double[][] estimatedValues_;

	int numberOfRuns_;

	public SMSEMOA_IGD(Problem problem) {
		super(problem);
	}

	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {

		populationSize_ = (Integer)this.getInputParameter("sizeOfPopulation");

		numberOfIterations_ = (Integer)this.getInputParameter("numberOfIterations");

		crossover_ = this.getOperator("crossover");
		mutation_ = this.getOperator("mutation");
		selection_ = this.getOperator("selection");

		fileName_ = (String)this.getInputParameter("fileName");
		numberOfRuns_ = (int)this.getInputParameter("numberOfRuns");

		estimatedValues_ = new double[numberOfIterations_+1][2];

		if(fileName_.length() == 0) {
			initLambda();
		} else {
			initLambda(fileName_);
		}

		int t = 0;
		int from = 1;
		int to;

		solutionSet_ = new ArrayList<Solution>();

		initialize();

		while(t < this.numberOfIterations_) {

			offspringSet_ = new ArrayList<Solution>();

			ArrayList<Solution> parents = new ArrayList<Solution>();
			ArrayList<Solution> children;

			parents.add((Solution)selection_.execute(solutionSet_));
			parents.add((Solution)selection_.execute(solutionSet_));

			children = (ArrayList<Solution>)crossover_.execute(parents);

			Solution s = (Solution)mutation_.execute(children.get(PseudoRandomGenerator.randInt(0, 2)));
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			offspringSet_.add(s);

			mergeSet_ = new ArrayList<Solution>();

			mergeSolutionSet(solutionSet_, offspringSet_);

			Ranking ranking = new NondominatedSort(mergeSet_);

			int remain = populationSize_;
			int index = 0;
			ArrayList<Solution> front = null;
			solutionSet_ = new ArrayList<Solution>();

			front = ranking.getSubFront(index);

			while ((remain > 0) && (remain >= front.size())) {

				for (int k = 0, size = front.size(); k < size; k++) {
					solutionSet_.add(front.get(k));
				} // for
				// Decrement remain
				remain = remain - front.size();
				// Obtain the next front
				index++;
				if (remain > 0) {
					front = ranking.getSubFront(index);
				} // if
			}

			ArrayList<Solution> sols = new ArrayList<>();
			if(remain > 0) {
				sols = EnvironmentalSelection(front);
				assert(remain == sols.size());
				solutionSet_.addAll(sols);
				remain -= sols.size();
			}
			t++;
			System.out.println("t: " + t);
//			//calculateIGD(solutionSet_, t);
//
//			if(t%1000 == 0) {
//				to = t;
//				PrintIGD(from, to);
//				PrintSolutionSet(to);
//				from = to + 1;
//			}

		}//while
//
//		PrintIGD(1,numberOfIterations_);

		return solutionSet_;
	}


	void initialize() throws ClassNotFoundException {
		for(int i = 0; i < populationSize_; i++) {
			Solution s = new Solution(problem_);
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			solutionSet_.add(s);
		}
	}


	void initLambda() {
		this.lambda = new ArrayList<>();
		try {
			FileReader fr = new FileReader("reference.csv");
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				lambda.add(refPoint);
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			System.err.println(e);
		}
	}


	void initLambda(String fileName) {
		this.lambda = new ArrayList<>();
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				lambda.add(refPoint);
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			System.err.println(e);
		}
	}


	void calculateIGD(ArrayList<Solution> solutionSet, int t) {
		assert(t>=0);
		InvertedGenerationalDistance igd = new InvertedGenerationalDistance(lambda, solutionSet);
		estimatedValues_[t-1][0] = t;
		estimatedValues_[t-1][1] = igd.CalculateIGD();
	}


	void PrintIGD(int from, int to) {
		try {
			File file = new File("IGD_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives()
								  + "_f" + from + "_t" + to + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = from-1; i < to; i++) {
				pw.println(estimatedValues_[i][0] + " " + estimatedValues_[i][1]);
			}
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	void PrintIGD() {
		try {
			File file = new File("IGD_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives()
								  + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			pw.println(estimatedValues_[this.numberOfIterations_][0] + " " + estimatedValues_[this.numberOfIterations_][1]);
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	void PrintSolutionSet(int to) {
		try {
			File file = new File("FUN_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives() +
								 "_t" + to + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < solutionSet_.size(); i++) {
				for(int j = 0; j < solutionSet_.get(i).getObjectives().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet_.get(i).getObjective(j));
					if(j < solutionSet_.get(i).getObjectives().length - 1)
						pw.print(" ");
				}
				pw.println();
			}
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	void mergeSolutionSet(ArrayList<Solution> set1, ArrayList<Solution> set2) {
		this.mergeSet_.addAll(set1);
		this.mergeSet_.addAll(set2);
	}


	ArrayList<Solution> EnvironmentalSelection(ArrayList<Solution> solutionSet) {
		assert(solutionSet.size()>0);
		int index = -1;
		double minIGD = Double.MAX_VALUE;

		long start = System.currentTimeMillis();
		ArrayList<Solution> sols = new ArrayList<>();

		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.clear();
			sols.addAll(solutionSet_);

			for(int j = 0; j < size; j++) {
				if(j == i) continue;
				sols.add(solutionSet.get(j));
			}

			InvertedGenerationalDistance igd = new InvertedGenerationalDistance(lambda, sols);
			double igdVal = igd.CalculateIGD();
//			igdVal *= -1.0;

			if(igdVal < minIGD) {
				index = i;
				minIGD = igdVal;
			}
		}

		long finish = System.currentTimeMillis();
		System.out.println("time: " + (finish - start));

		sols.clear();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			if(i == index) continue;
			sols.add(solutionSet.get(i));
		}

		return sols;
	}

	@Override
	public void setting() {
		// TODO 自動生成されたメソッド・スタブ

	}

}
