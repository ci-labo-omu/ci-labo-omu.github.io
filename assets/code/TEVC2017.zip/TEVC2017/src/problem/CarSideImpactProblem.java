package problem;

import java.util.HashMap;

import core.Problem;
import core.Solution;

public class CarSideImpactProblem extends Problem {

	int N_;
	int M_;
	int L_;

	public CarSideImpactProblem (HashMap<String, Object> map) {
		super(map);
		this.solutionType_ = "Real";
		this.N_ = 7;
		this.numberOfVariables_ = N_;
		this.M_ = 3;
		this.numberOfObjectives_ = M_;
		this.L_ = 10;
		this.numberOfConstraints_ = L_;
		this.lowerBounds_[0] = 0.5; this.upperBounds_[0] = 1.5;
		this.lowerBounds_[1] = 0.45; this.upperBounds_[1] = 1.35;
		this.lowerBounds_[2] = 0.5; this.upperBounds_[2] = 1.5;
		this.lowerBounds_[3] = 0.5; this.upperBounds_[3] = 1.5;
		this.lowerBounds_[4] = 0.875; this.upperBounds_[4] = 2.625;
		this.lowerBounds_[5] = 0.4; this.upperBounds_[5] = 1.2;
		this.lowerBounds_[6] = 0.4; this.upperBounds_[6] = 1.2;
	}

	double calculateF(double[] vars) {
		assert vars.length == N_ : "vars.length must be " + N_ + "!!";
		double F = 4.72 - 0.5*vars[3] - 0.19*vars[1]*vars[2];
		return F;
	}

	double calculateVMBP(double[] vars) {
		assert vars.length == N_ : "vars.length must be " + N_ + "!!";
		double VMBP = 10.58 - 0.674*vars[0]*vars[1]-0.67275*vars[1];
		return VMBP;
	}

	double calculateVFD(double[] vars) {
		assert vars.length == N_ : "vars.length must be " + N_ + "!!";
		double VFD = 16.45 - 0.489*vars[2]*vars[6] - 0.843*vars[4]*vars[5];
		return VFD;
	}

	double[] evaluateObj(double[] vars) {
		assert vars.length == N_ : "vars.length must be " + N_ + "!!";
		double[] objectives = new double[M_];
		objectives[0] = 1.98 + 4.9*vars[0] + 6.67*vars[1] + 6.98*vars[2] + 4.01*vars[3] + 1.78*vars[4]
							 + 0.00001*vars[5] + 2.73*vars[6];
		objectives[1] = calculateF(vars);
		objectives[2] = 0.5*(calculateVMBP(vars) + calculateVFD(vars));
		return objectives;
	}


	double[] evaluateCons(double[] vars) {
		assert vars.length == N_ : "vars.length must be " + N_ + "!!";
		double[] constraints = new double[L_];
		constraints[0] = 1.16 - 0.3717*vars[1]*vars[3] - 0.0092928*vars[2] - 1.0;
		constraints[1] = 0.261 - 0.0159*vars[0]*vars[1] - 0.06486*vars[0] - 0.019*vars[1]*vars[6]
						 + 0.0144*vars[2]*vars[4] + 0.0154464*vars[5] - 0.32;
		constraints[2] = 0.214 + 0.00817 * vars[4] - 0.045195*vars[0] - 0.0135168*vars[0] + 0.03099*vars[1]*vars[5]
						 - 0.018*vars[1]*vars[6] + 0.007176 * vars[2] + 0.023232*vars[2] - 0.00364*vars[4]*vars[5]
						 - 0.018*vars[1]*vars[1] - 0.32;
		constraints[3] = 0.74 - 0.61*vars[1] - 0.031296*vars[2] - 0.031872*vars[6] + 0.227*vars[1]*vars[1] - 0.32;
		constraints[4] = 28.98 + 3.818*vars[2] - 4.2*vars[0]*vars[1] + 1.27296*vars[5] - 2.68065*vars[6] - 32.0;
		constraints[5] = 33.86 + 2.95*vars[2] - 5.057*vars[0]*vars[1] -3.795*vars[1] - 3.4431*vars[6] + 1.45728 -32.0;
		constraints[6] = 46.36 - 9.9*vars[1] - 4.4505*vars[0] -32.0;
		constraints[7] = calculateF(vars) - 4.0;
		constraints[8] = calculateVMBP(vars) - 9.9;
		constraints[9] = calculateVFD(vars) - 15.7;
		return constraints;
	}


	double calculateCV(double[] constraints) {
		assert constraints.length == L_ : "constraints.length must be " + L_ + "!";
		double CV = 0.0;
		for(int i = 0; i < constraints.length; i++) {
			if(CV < constraints[i]) CV = constraints[i];
		}
		return CV;
	}


	@Override
	public final void evaluate(Solution solution) {
		double [] variables = new double[getNumberOfVariables()];
		for (int i = 0; i < getNumberOfVariables(); i++) variables[i] = (double)solution.getVariable(i);
		double [] f = evaluateObj(variables);
		for (int i = 0; i < f.length; i++) solution.setObjective(i, f[i]);
		double [] c = evaluateCons(variables);
		double CV = calculateCV(c);
		solution.setConstraintViolation(CV);
	}

}
