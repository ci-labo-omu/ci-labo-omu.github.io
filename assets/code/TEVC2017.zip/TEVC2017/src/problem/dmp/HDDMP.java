package problem.dmp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import core.Problem;
import core.Solution;

public class HDDMP extends Problem {


	int numberOfPlanes_;
	double[][][] point_;

	public HDDMP (HashMap<String, Object> map) {
		super(map);
		this.solutionType_ = "Real";
		problemName_ = "HDDMP";
		for(int i = 0; i < this.numberOfVariables_; i++) {
			this.lowerBounds_[i] = 0.0;
			this.upperBounds_[i] = 100.0;
		}
		this.numberOfPlanes_ = 1; // this parameter should be able to set by a user.
		point_ = new double[this.numberOfPlanes_][4][this.numberOfVariables_];
		point_[0][0] = setPointA_4obj(this.numberOfVariables_);
		point_[0][1] = setPointB_4obj(this.numberOfVariables_);
		point_[0][2] = setPointC_4obj(this.numberOfVariables_);
		if(this.numberOfObjectives_ == 3) point_[0][2] = setPointD_4obj(this.numberOfVariables_);
		point_[0][3] = setPointD_4obj(this.numberOfVariables_);

		try {
			File file = new File("Reference_m"+this.numberOfObjectives_+".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < this.numberOfObjectives_; i++) {
				for(int j = 0; j < this.numberOfVariables_; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(point_[0][i][j]);
					if(j < point_[0][i].length - 1)
						pw.print(",");
				}
				pw.println();
			}
			pw.close();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}


	double[] setPointA_4obj(int n) {
		double[] A = new double[n];
		for(int i = 0; i < n; i++) {
			A[i] = 25.0;
		}
		return A;
	}


	double[] setPointB_4obj(int n) {
		double[] B = new double[n];
		for(int i = 0; i < n; i++) {
			if(i%2==0) {
				B[i] = 75.0;
			} else {
				B[i] = 25.0;
			}
		}
		return B;
	}


	double[] setPointC_4obj(int n) {
		double[] C = new double[n];
		for(int i = 0; i < n; i++) {
			C[i] = 75.0;
		}
		return C;
	}


	double[] setPointD_4obj(int n) {
		double[] D = new double[n];
		for(int i = 0; i < n; i++) {
			if(i%2==0) {
				D[i] = 25.0;
			} else {
				D[i] = 75.0;
			}
		}
		return D;
	}


	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		double[] variables = new double[this.numberOfVariables_];
		for(int i = 0; i < variables.length; i++) variables[i] = solution.getVariable(i);
		double[] f = new double[this.numberOfObjectives_];
		for(int i = 0; i < f.length; i++) f[i] = calculateObj(variables, i);
		for(int i = 0; i < f.length; i++) solution.setObjective(i, f[i]);
	}


	double calculateObj(double[] vars, int obj) {
		double objVal = calculateDistance(vars, 0, obj);
		double dist;
		for(int i = 0; i < this.numberOfPlanes_; i++) {
			dist = calculateDistance(vars, i, obj);
			if(dist < objVal) objVal = dist;
		}
		return objVal;
	}


	double calculateDistance(double[] vars, int planeId, int obj) {
		double dist = 0.0;
		for(int i = 0; i < this.numberOfVariables_; i++)
			dist += (vars[i] - point_[planeId][obj][i]) * (vars[i] - point_[planeId][obj][i]);
		dist = Math.sqrt(dist);
		return dist;
	}


	@Override
	public ArrayList<Solution> getParetoSets(int nSols) {
		int nObjs = this.numberOfObjectives_;
		ArrayList<Solution> sols = new ArrayList<>();
		int size = (int)Math.floor((double)nSols / (double)nObjs/ (double)numberOfPlanes_);
		for(int id = 0; id < numberOfPlanes_; id++)
			for(int ob = 0; ob < nObjs; ob++) sols.addAll(getSolsOnLine(ob, size, id));
		return sols;
	}


	ArrayList<Solution> getSolsOnLine(int obj, int nSols, int planeId) {
		ArrayList<Solution> sols = new ArrayList<>();
		int nObjs = this.numberOfObjectives_;
		double[] line = new double[this.numberOfVariables_];
		double[] P1 = point_[planeId][obj%nObjs];
		double[] P2 = point_[planeId][(obj+1)%nObjs];
		for(int i = 0; i < line.length; i++) {
			line[i] = P2[i] - P1[i];
			line[i] /= (double)(nSols - 1);
		}
		for(int id = 0; id < nSols; id++) {
			Solution s = new Solution(this);
			for(int n = 0; n < line.length; n++) {
				s.setVariable(n, P1[n]+id*line[n]);
			}
			sols.add(s);
		}
		return sols;
	}

}
