package problem.dmp;

import java.util.HashMap;

import core.Problem;
import core.Solution;

public class DMP extends Problem {


	int numberOfPlanes_;
	double[][][] point_;

	public DMP (HashMap<String, Object> map) {
		super(map);
		this.solutionType_ = "Real";
		for(int i = 0; i < this.numberOfVariables_; i++) {
			this.lowerBounds_[i] = 0.0;
			this.upperBounds_[i] = 1.0;
		}
		this.numberOfPlanes_ = 1; // this parameter should be able to set by a user.
		point_ = new double[this.numberOfPlanes_][4][this.numberOfVariables_];
		point_[0][0][0] = 0.0;
		point_[0][0][1] = 0.0;
		point_[0][1][0] = 0.0;
		point_[0][1][1] = 1.0;
		point_[0][2][0] = 1.0;
		point_[0][2][1] = 0.0;
		point_[0][3][0] = 1.0;
		point_[0][3][1] = 1.0;
	}


	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		double[] variables = new double[this.numberOfVariables_];
		for(int i = 0; i < variables.length; i++) variables[i] = solution.getVariable(i);
		double[] f = new double[this.numberOfObjectives_];
		for(int i = 0; i < f.length; i++) f[i] = calculateObj(variables, i);
		for(int i = 0; i < f.length; i++) solution.setObjective(i, f[i]);
	}


	double calculateObj(double[] vars, int obj) {
		double objVal = calculateDistance(vars, 0, obj);
		double dist;
		for(int i = 0; i < this.numberOfPlanes_; i++) {
			dist = calculateDistance(vars, i, obj);
			if(dist < objVal) objVal = dist;
		}
		return objVal;
	}


	double calculateDistance(double[] vars, int planeId, int obj) {
		double dist = 0.0;
		for(int i = 0; i < this.numberOfVariables_; i++) {
			dist += (vars[i] - point_[planeId][obj][i]) * (vars[i] - point_[planeId][obj][i]);
		}
		dist = Math.sqrt(dist);
		return dist;
	}

}
