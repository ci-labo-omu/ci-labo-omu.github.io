package problem.zdt;

import java.util.HashMap;

import core.Problem;
import core.Solution;

public class ZDT3 extends Problem {

	int N_;
	int M_;
	int L_;

	public ZDT3 (HashMap<String, Object> map) {
		super(map);
		this.solutionType_ = "Real";
		this.N_ = 30;
		this.numberOfVariables_ = N_;
		this.M_ = 2;
		this.numberOfObjectives_ = M_;
		this.L_ = 0;
		this.numberOfConstraints_ = L_;
		for(int i = 0; i < this.numberOfVariables_; i++) {
			this.lowerBounds_[i] = 0.0;
			this.upperBounds_[i] = 1.0;
		}
	}

	//calculate distance function g(x)
	double calculateGx(double[] vars) {
		return 1.0;
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		double [] variables = new double[getNumberOfVariables()];
		for (int i = 0; i < getNumberOfVariables(); i++) variables[i] = (double)solution.getVariable(i);
		double g = calculateGx(variables);
		double[] f = new double[this.numberOfObjectives_];
		f[0] = variables[0];
		double fg = variables[0]/g;
		f[1] = (1.0 - Math.sqrt(fg) - fg*Math.sin(10.0*Math.PI*variables[0])) * g;
		f[0] = f[0]/0.8518;
		f[1] = (f[1]+0.773368557) / (1.0+0.773368557);
		for (int i = 0; i < f.length; i++) solution.setObjective(i, f[i]);
	}

}
