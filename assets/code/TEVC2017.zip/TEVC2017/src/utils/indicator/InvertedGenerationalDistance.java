package utils.indicator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import core.Solution;

public class InvertedGenerationalDistance {


	double invertedGenerationalDistance;
	ArrayList<Solution> pop = null;
	ArrayList<ArrayList<Double>> lambda;


	public InvertedGenerationalDistance(String fileName, ArrayList<Solution> pop){
		lambda = new ArrayList<>();
		this.pop = pop;
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				lambda.add(refPoint);
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			System.err.println(e);
		}
	}//Constructer


	public InvertedGenerationalDistance(String fileName, ArrayList<Solution> pop, boolean normalize){
		lambda = new ArrayList<>();
		this.pop = pop;
		int nObj = -1;
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++) refPoint.add(Double.parseDouble(array[j]));
				lambda.add(refPoint);
				nObj = array.length;
			}
			br.close();
			fr.close();
			if(normalize && this.lambda.size() > 0) normalization(nObj);
		} catch (IOException e) {
			System.err.println(e);
		}
	}//Constructer


	public InvertedGenerationalDistance(ArrayList<ArrayList<Double>> lambda, ArrayList<Solution> pop){
		this.lambda = lambda;
		this.pop = pop;
	}//Constructer


	public InvertedGenerationalDistance(ArrayList<ArrayList<Double>> lambda, ArrayList<Solution> pop, boolean normalize){
		this.lambda = lambda;
		this.pop = pop;
		if(normalize && this.lambda.size() > 0) normalization(this.lambda.get(0).size());
	}//Constructer


	public double CalculateIGD(){
		this.invertedGenerationalDistance = 0.0;

		for(int i = 0, size = lambda.size(); i < size; i++){
			invertedGenerationalDistance += CalculateDistance(lambda.get(i),this.pop);
		}

		invertedGenerationalDistance /= lambda.size();

		return invertedGenerationalDistance;
	}

	public double CalculateDistance(ArrayList<Double> referencePoint, ArrayList<Solution> pop){

		double minDistance = Double.MAX_VALUE;
		double Distance;


		for(int i = 0, psize = pop.size(); i < psize; i++){
			Distance = 0.0;
			for(int j = 0, m = pop.get(i).getObjectives().length; j < m; j++){
				Distance += Math.pow(pop.get(i).getObjective(j) - referencePoint.get(j), 2);
			}//for

			Distance = Math.sqrt(Distance);

			if(Distance < minDistance){
				minDistance = Distance;
			}//if
		}//for

		return minDistance;
	}


	public double CalculateDistance(ArrayList<Double> referencePoint, Solution pop){

		double minDistance = Double.MAX_VALUE;
		double Distance;

			Distance = 0.0;
			for(int j = 0, m = pop.getObjectives().length; j < m; j++){
				Distance += Math.pow(pop.getObjective(j) - referencePoint.get(j), 2);
			}//for

			Distance = Math.sqrt(Distance);

			if(Distance < minDistance){
				minDistance = Distance;
			}//if

		return minDistance;
	}


	public void normalization(int nObj) {
		double[] maximum = new double[nObj];
		double[] minimum = new double[nObj];
		for(int ob = 0; ob < nObj; ob++) {
			maximum[ob] = -Double.MAX_VALUE;
			minimum[ob] = Double.MAX_VALUE;
		}
		for(int id = 0, size = this.lambda.size(); id < size; id++) {
			for(int ob = 0; ob < nObj; ob++) {
				double val = this.lambda.get(id).get(ob);
				if(maximum[ob] < val) maximum[ob] = val;
				if(minimum[ob] > val) minimum[ob] = val;
			}
		}
		for(int id = 0, size = this.pop.size(); id < size; id++) {
			for(int ob = 0; ob < nObj; ob++) {
				double nval = (this.pop.get(id).getObjective(ob) - minimum[ob]) / (maximum[ob] - minimum[ob]);
				this.pop.get(id).setObjective(ob, nval);
			}
		}
		for(int id = 0, size = this.lambda.size(); id < size; id++) {
			for(int ob = 0; ob < nObj; ob++) {
				double nval = (this.lambda.get(id).get(ob) - minimum[ob]) / (maximum[ob] - minimum[ob]);
				this.lambda.get(id).set(ob, nval);
			}
		}
	}

}
