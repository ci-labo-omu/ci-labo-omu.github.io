package utils.indicator;

import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class Hypervolume {

	ArrayList<Solution> sols_;
	double[] reference_;
	boolean maximize_ = true;
	int nObj_debug_ = 4;

	public Hypervolume(ArrayList<Solution> S, double[] R, boolean maximize) {
		this.sols_ = new ArrayList<>();
		solutionSetDeepCopy(S, sols_);
		this.reference_ = R;
		this.maximize_ = maximize;
	}


	//this method calculates the hypervolume value for maximization case.
	//if minimization case, all solutions and the reference point are multipled by (-1).
	public double execute() {
//		ParetoComparator.setOptimize("max");
		//this.sols_ = getNondominatedSolution(getStrongDominateSolution(this.sols_));
		double value = 0.0;
		if(sols_.size() == 0) return value;
		if(this.sols_.get(0).getNumberOfObjectives() == 2) {
			value = calculate2DHV(sols_, reference_, sols_.size());
		} else if(nObj_debug_ == 3){
			HSO hso = new HSO(sols_, reference_, true);
			value = hso.execute();
		} else {
			WFG wfg = new WFG(sols_, reference_, true);
			value = wfg.execute(sols_);
		}
//		System.out.println("HV value: "+value);
//		if(maximize_) {
//			ParetoComparator.setOptimize("min");
//		}
		return value;
	}


	void solutionSetDeepCopy(ArrayList<Solution> popFrom, ArrayList<Solution> popTo) {
		if(popFrom.size()==0) return;
		if(popTo==null) popTo = new ArrayList<>();
		for(int i = 0, size = popFrom.size(); i < size; i++) {
			Solution s = new Solution(popFrom.get(i));
			s.setIndividualNumber(i);
			popTo.add(s);
		}
	}


	double calculate2DHV(ArrayList<Solution> pl, double[] reference, int ceil) {
		if(pl.size()==0)return 0.0;
		Collections.sort(pl, new ObjectiveComparator(1, false));
		double value = (pl.get(0).getObjective(0) - reference[0]) * (pl.get(0).getObjective(1) - reference[1]);
		for(int id = 0; id < ceil - 1; id++) {
			value += (pl.get(id+1).getObjective(0) - pl.get(id).getObjective(0)) * (pl.get(id+1).getObjective(1) - reference[1]);
		}
		return value;
	}


	void multipleMinus() {
		for(int id = 0; id < sols_.size(); id++) {
			for(int ob = 0, M = sols_.get(id).getNumberOfObjectives(); ob < M; ob++)
				sols_.get(id).setObjective(ob, -1.0*sols_.get(id).getObjective(ob));
		}
		for(int ob = 0; ob < reference_.length; ob++) reference_[ob] *= -1.0;
	}


	//this method checks that a solution strong-dominate the reference point for maximization case.
	//if you want to check for minimization case, all solutions and the reference point are multipled by (-1).
	static boolean strongDominate(double[] r, Solution sol) {
		boolean dominate = true;
		for(int m = 0, numberOfObjectives = r.length; m < numberOfObjectives; m++) {
			if(sol.getObjective(m) <= r[m]) {
				dominate = false;
				break;
			}
		}
		return dominate;
	}


	ArrayList<Solution> getStrongDominateSolution(ArrayList<Solution> S) {
		ArrayList<Solution> sols = new ArrayList<>();
		for(int id = 0; id < S.size(); id++) {
			if(strongDominate(reference_, S.get(id))) sols.add(S.get(id));
		}
		return sols;
	}


	ArrayList<Solution> getNondominatedSolution(ArrayList<Solution> S) {
		Ranking ranking = new NondominatedSort(S);
		return ranking.getSubFront(0);
	}

}
