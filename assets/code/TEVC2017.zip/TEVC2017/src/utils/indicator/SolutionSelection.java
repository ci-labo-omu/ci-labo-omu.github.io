package utils.indicator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Solution;
import utils.comparator.ObjectiveComparator;

public class SolutionSelection {
	static ArrayList<ArrayList<Double>> population_;
	static ArrayList<ArrayList<Double>> sampledSolutions_;
	static String indicatorName_ = "hv";
	static boolean minimize_ = true;
	static boolean normalize_ = false;
	static String fileName_ = "";
	static String separator_ = "";
	static int numberOfSamples_ = 50;
	static int seed_ = 1;
	static int numberOfObjectives_ = -1;
	static double ref_ = 1.1;

	public static void main(String args[]) {
		setting(args);
		initialize();
		if(normalize_) normalization();
		printPopulation();
		execute();
		printObjectives();
	}

	public static void initialize() {
		population_ = new ArrayList<>();
		sampledSolutions_ = new ArrayList<>();
		try {
			if(fileName_.equalsIgnoreCase("")) fileName_ = "objective.csv";
			FileReader fr = new FileReader(fileName_);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			if(separator_.equalsIgnoreCase("")) separator_ = ",";
			while((temp = br.readLine()) != null){
				String[] array = temp.split(separator_);
				if(numberOfObjectives_!=-1 && numberOfObjectives_!=array.length) {
					System.err.println("There are several the number of objectives");
					System.exit(-1);
				} else if(numberOfObjectives_==-1)
					numberOfObjectives_ = array.length;
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				population_.add(refPoint);
			}
			br.close();
			fr.close();
			Random rnd = new Random(seed_);
			Collections.shuffle(population_, rnd);
		} catch (IOException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}


	public static void setting(String args[]) {
		if(args.length < 2) {
			System.err.println("The number of arguments must be more than 1 !");
			System.exit(-1);
		}
		for(int i = 0; i < args.length; i++) {
			if(args[i].equalsIgnoreCase("-fn")) {
				fileName_ = args[i+1];
			} else if(args[i].equalsIgnoreCase("-pop")) {
				numberOfSamples_ = Integer.parseInt(args[i+1]);
			} else if(args[i].equalsIgnoreCase("-indi")) {
				indicatorName_ = args[i+1];
			} else if(args[i].equalsIgnoreCase("-sep")) {
				separator_ = args[i+1];
			} else if(args[i].equalsIgnoreCase("-run")) {
				seed_ = Integer.parseInt(args[i+1]);
			} else if(args[i].equalsIgnoreCase("-refHV")) {
				ref_ = Double.parseDouble(args[i+1]);
			} else if(args[i].equalsIgnoreCase("-min")) {
				minimize_ = Boolean.parseBoolean(args[i+1]);
			} else if(args[i].equalsIgnoreCase("-norm")) {
				normalize_ = Boolean.parseBoolean(args[i+1]);
			}
		}
	}


	public static void normalization() {
		double min, max, value, normValue, numerator;
		for(int j = 0; j < numberOfObjectives_; j++) {
			max = -Double.MAX_VALUE;
			min = Double.MAX_VALUE;
			for(int i = 0; i < population_.size(); i++) {
				value = population_.get(i).get(j);
				if(min > value) min = value;
				if(max < value) max = value;
			}
			numerator = max - min;
			if(numerator < 1.0e-06) numerator = 1.0e-06;
			for(int i = 0; i < population_.size(); i++) {
				normValue = (population_.get(i).get(j) - min) / numerator;
				population_.get(i).set(j, normValue);
			}
		}
	}


	public static void execute() {
		double bestPerformanceValue, performanceValue;
		int bestSolutionId = -1;
		ArrayList<ArrayList<Double>> sols = new ArrayList<>();
		while(sampledSolutions_.size() < numberOfSamples_) {
			if(indicatorName_.equalsIgnoreCase("hypervolume") || indicatorName_.equalsIgnoreCase("hv")) {
				bestPerformanceValue = 0.0;
			} else if(indicatorName_.equalsIgnoreCase("igd")) {
				bestPerformanceValue = Double.MAX_VALUE;
			} else {
				bestPerformanceValue = 0.0;
			}
			for(int i = 0; i < population_.size(); i++) {
				performanceValue = calculateMeasure(population_.get(i));
				if(indicatorName_.equalsIgnoreCase("hypervolume") || indicatorName_.equalsIgnoreCase("hv")) {
					if(bestPerformanceValue < performanceValue) {
						bestPerformanceValue = performanceValue;
						bestSolutionId = i;
					}
				} else if(indicatorName_.equalsIgnoreCase("igd")) {
					if(bestPerformanceValue > performanceValue) {
						bestPerformanceValue = performanceValue;
						bestSolutionId = i;
					}
				}
			}
			sampledSolutions_.add(population_.get(bestSolutionId));
			population_.remove(bestSolutionId);
		}
	}


	public static double calculateMeasure(ArrayList<Double> sample) {
		double performanceValue = 0.0;
		if(indicatorName_.equalsIgnoreCase("hypervolume") || indicatorName_.equalsIgnoreCase("hv")) {
			ArrayList<Solution> sols = new ArrayList<>();
			ArrayList<Double> x = new ArrayList<>();
			Solution s;
			for(int i = 0; i < sampledSolutions_.size(); i++) {
				s = new Solution(x, sampledSolutions_.get(i), "Real");
				sols.add(s);
			}
			s = new Solution(x, sample, "Real");
			sols.add(s);
			double[] r = new double[numberOfObjectives_];
			for(int i = 0; i < r.length; i++) r[i] = ref_;
			Collections.sort(sols, new ObjectiveComparator(0, minimize_));
			HSO hso = new HSO(sols, r, !minimize_);
			performanceValue = hso.execute();
		} else if(indicatorName_.equalsIgnoreCase("igd")) {

		}
		return performanceValue;
	}


	public static void printPopulation() {
		try {
			File file = new File("normalizedPopulation.csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < population_.size(); i++) {
				for(int j = 0; j < numberOfObjectives_; j++) {
					pw.print(population_.get(i).get(j));
					if(j != numberOfObjectives_-1) pw.print(",");
				}
				pw.println();
			}
			pw.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}


	public static void printObjectives() {
		try {
			File file = new File("FUN_r" + seed_ + "_m" + numberOfObjectives_ + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < sampledSolutions_.size(); i++) {
				for(int j = 0; j < numberOfObjectives_; j++) {
					pw.print(sampledSolutions_.get(i).get(j));
					if(j != numberOfObjectives_-1) pw.print(",");
				}
				pw.println();
			}
			pw.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}


}
