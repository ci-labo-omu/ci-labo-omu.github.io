package utils.indicator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;

public class IHSO {
	int numberOfObjectives;
	Solution solution;
	ArrayList<Solution> solutionSet;
	double[] referencePoint;


	public class Portion{
		ArrayList<Solution> sols;
		double value;

		Portion(double val, ArrayList<Solution> pop) {
			sols = new ArrayList<>();
			for(int i = 0, size = pop.size(); i < size; i++) {
				Solution s = new Solution(pop.get(i));
				sols.add(s);
			}
			value = val;
		}

	}

	public IHSO(ArrayList<Solution> pop, double[] r, Solution sol) {
		this.solution = new Solution(sol);
		this.solutionSet = deleteDuplicatedSolution(pop);
		this.referencePoint = new double[r.length];
		referencePointDeepCopy(r, this.referencePoint);
		assert(this.referencePoint.length == this.solutionSet.get(0).getObjectives().length);
		if(this.solutionSet.size()==0) this.numberOfObjectives = 0;
		this.numberOfObjectives = this.referencePoint.length;
	}


	public double execute() {
		Solution z = solution;
		Collections.sort(this.solutionSet, new ObjectiveComparator(0, false));
		Portion portion = new Portion(1.0, solutionSet);
		ArrayList<Portion> s = new ArrayList<>();
		s.add(portion);
		for(int i = 0; i < this.numberOfObjectives-1; i++) {
			ArrayList<Portion> sTemp = new ArrayList<>();
			for(Portion port : s) {
				for(Portion por : slice(z, port.sols, i)) {
					double value = port.value * por.value;
					sTemp.add(new Portion(value, por.sols));
				}
			}
			s.clear();
			s.addAll(sTemp);
		}

		double vol = 0.0;
		for(Portion port : s) {
			double value = 0.0;
			if(port.sols.size()==0) {
				value = Math.abs(z.getObjective(this.numberOfObjectives-1)
						- this.referencePoint[this.numberOfObjectives - 1]);
			} else {
				value = Math.abs(z.getObjective(this.numberOfObjectives-1)
						- port.sols.get(0).getObjective(this.numberOfObjectives-1));
			}
			vol += port.value * value;
		}
		return vol;
	}


	ArrayList<Portion> slice(Solution z, ArrayList<Solution> pop, int k) {
		assert(pop.size()>0);
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		ArrayList<Solution> ql = new ArrayList<>();
		ArrayList<Portion> s = new ArrayList<>();
		double v = z.getObjective(k);
		boolean dominated = false;

		while((pl.size() > 0) && !dominated) {
			Solution p = new Solution(pl.get(0));
			pl.remove(0);
			if(beats(v, p.getObjective(k))) {
				double value = Math.abs(v - p.getObjective(k));
				Portion portion = new Portion(value, ql);
				s.add(portion);
				v = p.getObjective(k);
			}
			ql = insert(p, k+1, ql);
			dominated = dominates(p, z, k+1);
		}
		if(!dominated) {
			double value = Math.abs(v - this.referencePoint[k]);
			Portion portion = new Portion(value, ql);
			s.add(portion);
		}
		return s;
	}


	ArrayList<Solution> insert(Solution p, int k, ArrayList<Solution> pop) {
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		ArrayList<Solution> ql = new ArrayList<>();
		while((pl.size() > 0) && beats(pl.get(0).getObjective(k), p.getObjective(k))) {
			ql.add(pl.get(0));
			pl.remove(0);
		}
		ql.add(p);
		while(pl.size() > 0) {
			if(!dominates(p, pl.get(0), k)) ql.add(pl.get(0));
			pl.remove(0);
		}
		return ql;
	}


	boolean dominates(Solution p, Solution q, int k) {
		boolean d = true;
		int cn = k;
		while(d && cn < this.numberOfObjectives) {
			d = !beats(q.getObjective(cn), p.getObjective(cn));
			cn++;
		}
		return d;
	}


	boolean beats(double x, double y) {
		boolean beat = false;
		if(x > y) beat = true;
		return beat;
	}


	ArrayList<Solution> tail(ArrayList<Solution> pop) {
		ArrayList<Solution> solutionSet = new ArrayList<>();
		for(int i = 1, size = pop.size(); i < size; i++) {
			solutionSet.add(pop.get(i));
		}
		assert(solutionSet.size()+1 == pop.size());
		return solutionSet;
	}


	static ArrayList<Solution> convertToMinus(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		assert(r.length == solutionSet.get(0).getObjectives().length);
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < r.length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		for(int i = 0; i < r.length; i++) {
			r[i] *= -1.0;
		}
		return sols;
	}


	void solutionSetDeepCopy(ArrayList<Solution> popFrom, ArrayList<Solution> popTo) {
		if(popFrom.size()==0) return;
		for(int i = 0, size = popFrom.size(); i < size; i++) {
			Solution s = new Solution(popFrom.get(i));
			popTo.add(s);
		}
	}


	void referencePointDeepCopy(double[] rFrom, double[] rTo) {
		if(rFrom.length==0) return;
		for(int i = 0, size = rFrom.length; i < size; i++) {
			rTo[i] = rFrom[i];
		}
	}


	static ArrayList<Solution> deleteNotStrongDominatingSolution(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			if(strongDominate(r, solutionSet.get(i)))
				sols.add(new Solution(solutionSet.get(i)));
		}
		return sols;
	}


	static boolean strongDominate(double[] r, Solution sol) {
		boolean dominate = true;
		for(int m = 0, numberOfObjectives = r.length; m < numberOfObjectives; m++) {
			if(sol.getObjective(m) <= r[m]) {
				dominate = false;
				break;
			}
		}
		return dominate;
	}


	ArrayList<Solution> deleteDuplicatedSolution(ArrayList<Solution> solutionSet) {
		Solution sol = new Solution(this.solution);
		ArrayList<Solution> sols = new ArrayList<>();
		sols.add(new Solution(solutionSet.get(0)));
		for(int i = 1, size = solutionSet.size(); i < size; i++) {
			boolean skipFlag = false;
			boolean duplicated = duplicate(sol, solutionSet.get(i));
			if(!duplicated) sols.add(new Solution(solutionSet.get(i)));
		}
		assert(sols.size() <= solutionSet.size());
		return sols;
	}


	static boolean duplicate(Solution sol1, Solution sol2) {
		boolean duplicated = true;
		assert(sol1.getObjectives().length == sol2.getObjectives().length);
		for(int m = 0, numberOfObjectives = sol1.getObjectives().length; m < numberOfObjectives; m++) {
			if(sol1.getObjective(m) != sol2.getObjective(m)) {
				duplicated = false;
				break;
			}
		}
		return duplicated;
	}


	public static void makeContributionMap(String allFileName, String allRefs) {
		String[] fileName = allFileName.split(",");
		String[] refArray = allRefs.split(",");
		double[] refs = new double[refArray.length];
		for (int i = 0; i < refs.length; i++) refs[i] = Double.parseDouble(refArray[i]);

		ArrayList<ArrayList<Solution>> allSolutionSet = new ArrayList<>();
		for(int fileId = 0; fileId < fileName.length; fileId++) {
			ArrayList<Solution> solutionSet = new ArrayList<>();
			try {
				FileReader fr = new FileReader(fileName[fileId]);
				BufferedReader br = new BufferedReader(fr);
				String temp;

				ArrayList<Double> x = new ArrayList<>();
				String type = "Real";

				while((temp = br.readLine()) != null){
					String[] array = temp.split(",");
					ArrayList<Double> refPoint = new ArrayList<>();
					for(int j = 0; j < array.length; j++){
						refPoint.add(Double.parseDouble(array[j]));
					}
					Solution s = new Solution(x, refPoint, type);
					solutionSet.add(s);
				}
				br.close();
				fr.close();

				allSolutionSet.add(solutionSet);
			} catch (IOException e) {
				System.out.println(fileName[fileId]);
				System.err.println(e);
				System.exit(-1);
			}
		}


		ArrayList<ArrayList<ArrayList<Double>>> contribution = new ArrayList<>();

		double maxCont = -Double.MAX_VALUE;
		//maxCont = 12.0;
		double minCont = 0.0;
		double maxPlotSize = 12.0;              // you should set plotsize
		double minPlotSize = 1.0; // HV Contribution Heat Map setting
//		double minPlotSize = 0.0; // GECCO2017 

		for(int refId = 0; refId < refs.length; refId++) {
			ArrayList<ArrayList<Double>> eachRefCont = new ArrayList<>();
			System.out.println("r: " + refs[refId]);
			for(int fileId = 0; fileId < allSolutionSet.size(); fileId++) {
				ArrayList<Solution> solutionSet = allSolutionSet.get(fileId);
				ArrayList<Double> eachSolSetCont = new ArrayList<>();
				for(int i = 0; i < solutionSet.size(); i++) eachSolSetCont.add(0.0);

				int m = solutionSet.get(0).getObjectives().length;
				double[] r = new double[m];
				for(int i = 0; i < m; i++) {
					r[i] = refs[refId];
				}

				boolean maximize = false;

				if(!maximize)
					solutionSet = convertToMinus(r, solutionSet);

				for(int i = 0; i < r.length; i++)
					Collections.sort(solutionSet, new ObjectiveComparator(i, false));

//				for(int i = 0; i < solutionSet.size(); i++) {
//					for(int j = 0; j < solutionSet.get(i).getNumberOfObjectives(); j++) {
//						System.out.print(solutionSet.get(i).getObjective(j) + "\t");
//					}
//					System.out.println();
//				}
//				System.out.println();
//				System.out.println();

				for(int i = 0, size = solutionSet.size(); i < size; i++) {
					if(!strongDominate(r, solutionSet.get(i))) {
						eachSolSetCont.set(i,0.0);
						minCont = 0.0;
						continue;
					}
					if((i < solutionSet.size()-1) && (duplicate(solutionSet.get(i), solutionSet.get(i+1)))) {
						eachSolSetCont.set(i,0.0);
						minCont = 0.0;
						continue;
					}

					ArrayList<Solution> sols = new ArrayList<>();
					Solution z = null;
					for(int j = 0; j < size; j++) {
						if(i == j) {
							z = new Solution(solutionSet.get(j));
						} else {
							sols.add(solutionSet.get(j));
						}
					}
					IHSO ihso = new IHSO(sols, r, z);
					double vol = ihso.execute();
					eachSolSetCont.set(i, vol);
					if(vol < minCont) minCont = vol;
					if(vol > maxCont) maxCont = vol;
					//if(maxCont < vol && !(refs[refId] == 2.0) || !skipFlag(solutionSet.get(i))) maxCont = vol;
					ihso = null;
					//System.out.println("end of calculation one contribution");
				}

				if(!maximize)
					solutionSet = convertToMinus(r, solutionSet);

				eachRefCont.add(eachSolSetCont);
			}//end of fileId loop
			contribution.add(eachRefCont);
			//System.out.println("end loop of fileId");
		}//end of refId loop

		double sum = maxCont - minCont;

		System.out.println("maxCont: " + maxCont);
		System.out.println("minCont: " + minCont);

//
//		minCont /= sum;
//		maxCont /= sum;

		double coefficient = (maxPlotSize - minPlotSize) / (maxCont);

		for(int refId = 0; refId < refs.length; refId++) {
			for(int fileId = 0; fileId < allSolutionSet.size(); fileId++) {
				ArrayList<Solution> solutionSet = allSolutionSet.get(fileId);
				int m = solutionSet.get(0).getObjectives().length;
				double[] r = new double[m];
				for(int i = 0; i < m; i++) {
					r[i] = refs[refId];
				}
				boolean maximize = false;
				if(!maximize)
					solutionSet = convertToMinus(r, solutionSet);
				for(int i = 0; i < m; i++)
					Collections.sort(solutionSet, new ObjectiveComparator(i, false));
				if(!maximize)
					solutionSet = convertToMinus(r, solutionSet);
				ArrayList<Double> eachSolSetCont = new ArrayList<>();
				for(int i = 0, size = solutionSet.size(); i < size; i++) eachSolSetCont.add(contribution.get(refId).get(fileId).get(i));
				for(int i = 0, size = solutionSet.size(); i < size; i++) {
					double cont = eachSolSetCont.get(i);
//					if(sum < 1.0e-10) {
//						cont = 1.1;
//					} else if(cont == 0.0) {
//
//					} else {
//						cont = coefficient * (cont - minCont) + minPlotSize;
//					}
					if(cont == 0.0) {

					} else {
						cont = coefficient * (cont) + minPlotSize;
					}
					eachSolSetCont.set(i, cont);
				}
				try {
					//System.out.println("write a file");
				File file = new File("c_f" + fileId + "_ref" + refs[refId] + ".csv");
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

				for(int i = 0; i < solutionSet.size(); i++) {
					if(eachSolSetCont.get(i) == 1.0) continue;

					for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
							pw.print(solutionSet.get(i).getObjective(j));
						if(j < solutionSet.get(i).getObjectives().length - 1)
							pw.print(",");
					}
					pw.print("," + eachSolSetCont.get(i) + ",0x403102");
					pw.println();
				}
				pw.close();

				file = new File("valueOfCont" + fileId + "_ref" + refs[refId] + ".csv");
				pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

				for(int i = 0; i < solutionSet.size(); i++) {
					if(eachSolSetCont.get(i) == 1.0) continue;

					for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
							pw.print(solutionSet.get(i).getObjective(j));
						if(j < solutionSet.get(i).getObjectives().length - 1)
							pw.print(",");
					}
					pw.print("," + contribution.get(refId).get(fileId).get(i) + ",0x403102");
					pw.println();
				}
				pw.close();

				} catch (IOException e) {
					System.err.println(e);
					System.exit(-1);
				}
			}
		}
		//System.out.println("Finish");
	}


	public static boolean skipFlag(Solution s) {
		boolean skip = false;
		if((s.getObjective(0) == -1.0 && s.getObjective(1) == -1.0 && s.getObjective(2) == 0.0)
		|| (s.getObjective(0) == -1.0 && s.getObjective(1) == 0.0 && s.getObjective(2) == -1.0)
		|| (s.getObjective(0) == 0.0 && s.getObjective(1) == -1.0 && s.getObjective(2) == -1.0)) {
			skip = true;
		}
		System.out.println("skip!");
		return skip;
	}


	public static void main(String args[]) {
		makeContributionMap(args[0], args[1]);
	}
}
