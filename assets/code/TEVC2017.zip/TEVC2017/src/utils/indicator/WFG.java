package utils.indicator;

import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class WFG {
	ArrayList<Solution> sols_;
	double[] reference_;
	boolean maximize_ = true;
	int nObj_;

	public WFG(ArrayList<Solution> S, double[] R, boolean maximize) {
		this.sols_ = S;
		this.reference_ = R;
		this.maximize_ = maximize;
		this.nObj_ = reference_.length;
	}

	public double execute(ArrayList<Solution> pl) {
		if(pl.size() == 1) return inclhv(pl.get(0));
		if(pl.size() == 2) return iex2(pl, reference_);

		if(nObj_ == 2) return hv2(pl, reference_, pl.size());

		nObj_--;
		Collections.sort(pl, new ObjectiveComparator(nObj_, false));
		double value = 0.0;
		while(pl.size() > 2) {
			Solution s = new Solution(pl.get(pl.size()-1));
			pl.remove(pl.size()-1);
			value += (s.getObjective(nObj_) - reference_[nObj_]) * exclhv(s, pl);
		}
		nObj_++;
		value += iex2(pl, reference_);
//		System.out.println("wfg execute!!!");
//		System.out.println("pl.size: " + pl.size());
		return value;
	}


	double exclhv(Solution s, ArrayList<Solution> pl) {
		return inclhv(s) - execute(limitset(s, pl));
	}


	double inclhv(Solution p) {
		double retval = p.getObjective(0) - reference_[0];
		for(int ob = 1; ob < nObj_; ob++)
			retval *= (p.getObjective(ob) - reference_[ob]);
		return retval;
	}


	ArrayList<Solution> limitset(Solution s, ArrayList<Solution> pl) {
		ArrayList<Solution> ql = new ArrayList<>();
		ADD_NONDOMINATED:
		for(int id = 0; id < pl.size(); id++) {
			Solution w = worse(pl.get(id), s);
			for(int qlId = 0; qlId < ql.size(); qlId++) {
				switch(projectionDominanceEqual(ql.get(qlId), w, nObj_)) {
				case 1:
					ql.remove(qlId--);
					break;
				case 2:
				case -1:
					continue ADD_NONDOMINATED;
				default:
				}
			}
			ql.add(w);
		}
		return ql;
	}


	ArrayList<Solution> nds(ArrayList<Solution> pl) {
		Ranking ranking = new NondominatedSort(pl);
		return ranking.getSubFront(0);
	}


	Solution worse(Solution s1, Solution s2) {
		Solution w = new Solution(s1.getNumberOfVariables(), nObj_, s1.getSolutionType());
		for(int ob = 0; ob < w.getNumberOfObjectives(); ob++)
			w.setObjective(ob, Math.min(s1.getObjective(ob), s2.getObjective(ob)));
		return w;
	}


	double hv2(ArrayList<Solution> pl, double[] reference, int ceil) {
		Collections.sort(pl, new ObjectiveComparator(1, false));
		double value = (pl.get(0).getObjective(0) - reference_[0]) * (pl.get(0).getObjective(1) - reference_[1]);
		for(int id = 0; id < ceil - 1; id++)
			value += (pl.get(id+1).getObjective(0) - pl.get(id).getObjective(0)) * (pl.get(id+1).getObjective(1) - reference_[1]);
		return value;
	}


	double hv2Sorted(ArrayList<Solution> pl, double[] reference, int ceil) {
		double retval = (pl.get(0).getObjective(0) - reference[0]) * (pl.get(0).getObjective(1) - reference[1]);
		for(int id = 0; id < sols_.size() - 1; id++)
			retval += (sols_.get(id+1).getObjective(0) - sols_.get(id).getObjective(0)) * (sols_.get(id+1).getObjective(1) - reference_[1]);

		return retval;
	}


	double iex2(ArrayList<Solution> pl, double[] reference) {
		double union = 1.0;
		for(int ob = 0; ob < nObj_; ob++) {
			union *= Math.min(pl.get(0).getObjective(ob), pl.get(1).getObjective(ob)) - reference[ob];
		}
		return inclhv(pl.get(0)) - union + inclhv(pl.get(1));
	}


	int projectionDominanceEqual(Solution s1, Solution s2, int nObj) {
		boolean s1Superior = false;
		boolean s1Inferior = false;
		for(int ob = 0; ob < nObj; ob++) {
			if(s1.getObjective(ob) > s2.getObjective(ob)) {
				s1Superior = true;
			} else if(s1.getObjective(ob) < s2.getObjective(ob)) {
				s1Inferior = true;
			}
		}

		if(s1Superior) {
			return s1Inferior ? 0 : -1;
		} else {
			return s1Inferior ? 1 : 2;
		}
	}


	void multipleMinus() {
		for(int id = 0; id < sols_.size(); id++) {
			for(int ob = 0, M = sols_.get(id).getNumberOfObjectives(); ob < M; ob++)
				sols_.get(id).setObjective(ob, -1.0*sols_.get(id).getObjective(ob));
		}
		for(int ob = 0; ob < reference_.length; ob++) reference_[ob] *= -1.0;
	}

}
