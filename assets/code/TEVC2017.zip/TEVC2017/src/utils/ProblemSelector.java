package utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import core.Problem;
import problem.CarSideImpactProblem;
import problem.dmp.DMP;
import problem.dmp.HDDMP;
import problem.dtlz.ConvexDTLZ2;
import problem.dtlz.DTLZ1;
import problem.dtlz.DTLZ2;
import problem.dtlz.DTLZ3;
import problem.dtlz.DTLZ4;
import problem.dtlz.DTLZ5;
import problem.dtlz.DTLZ6;
import problem.dtlz.DTLZ7;
import problem.dtlz.InvertedDTLZ1;
import problem.dtlz.InvertedDTLZ2;
import problem.dtlz.MinusDTLZ1;
import problem.dtlz.MinusDTLZ2;
import problem.dtlz.MinusDTLZ3;
import problem.dtlz.MinusDTLZ4;
import problem.dtlz.NormalizedDTLZ1;
import problem.dtlz.NormalizedMinusDTLZ1;
import problem.wfg.MinusWFG1;
import problem.wfg.MinusWFG2;
import problem.wfg.MinusWFG3;
import problem.wfg.MinusWFG4;
import problem.wfg.NormalizedMinusWFG1;
import problem.wfg.NormalizedMinusWFG2;
import problem.wfg.NormalizedMinusWFG3;
import problem.wfg.NormalizedMinusWFG4;
import problem.wfg.NormalizedWFG1;
import problem.wfg.NormalizedWFG2;
import problem.wfg.NormalizedWFG3;
import problem.wfg.NormalizedWFG4;
import problem.wfg.WFG1;
import problem.wfg.WFG2;
import problem.wfg.WFG3;
import problem.wfg.WFG4;
import problem.wfg.WFG5;
import problem.wfg.WFG6;
import problem.wfg.WFG7;
import problem.wfg.WFG8;
import problem.wfg.WFG9;
import problem.zdt.ZDT1;
import problem.zdt.ZDT2;
import problem.zdt.ZDT3;

public class ProblemSelector {

	public ProblemSelector() {}


	public static Object getProblem(String str, HashMap<String, Object> map) throws FileNotFoundException, IOException, ClassNotFoundException {
		Problem problem = null;

		if(str.equalsIgnoreCase("DTLZ1")) {
			problem = new DTLZ1(map);
		} else if(str.equalsIgnoreCase("nDTLZ1")) {
			problem = new NormalizedDTLZ1(map);
		} else if(str.equalsIgnoreCase("mDTLZ1")) {
			problem = new MinusDTLZ1(map);
		} else if(str.equalsIgnoreCase("nmDTLZ1")) {
			problem = new NormalizedMinusDTLZ1(map);
		} else if(str.equalsIgnoreCase("InvDTLZ1")) {
			problem = new InvertedDTLZ1(map);
		} else if(str.equalsIgnoreCase("ConvDTLZ2")) {
			problem = new ConvexDTLZ2(map);
		} else if(str.equalsIgnoreCase("InvDTLZ2")) {
			problem = new InvertedDTLZ2(map);
		} else if(str.equalsIgnoreCase("DTLZ2")) {
			problem = new DTLZ2(map);
		} else if(str.equalsIgnoreCase("mDTLZ2")) {
			problem = new MinusDTLZ2(map);
		} else if(str.equalsIgnoreCase("DTLZ3")) {
			problem = new DTLZ3(map);
		} else if(str.equalsIgnoreCase("mDTLZ3")) {
			problem = new MinusDTLZ3(map);
		} else if(str.equalsIgnoreCase("DTLZ4")) {
			problem = new DTLZ4(map);
		} else if(str.equalsIgnoreCase("mDTLZ4")) {
			problem = new MinusDTLZ4(map);
		} else if(str.equalsIgnoreCase("DTLZ5")) {
			problem = new DTLZ5(map);
		} else if(str.equalsIgnoreCase("DTLZ6")) {
			problem = new DTLZ6(map);
		} else if(str.equalsIgnoreCase("DTLZ7")) {
			problem = new DTLZ7(map);
		} else if(str.equalsIgnoreCase("ZDT1")) {
			problem = new ZDT1(map);
		} else if(str.equalsIgnoreCase("ZDT2")) {
			problem = new ZDT2(map);
		} else if(str.equalsIgnoreCase("ZDT3")) {
			problem = new ZDT3(map);
		} else if(str.equalsIgnoreCase("DMP")) {  // distance minimization problem
			problem = new DMP(map);
		}else if(str.equalsIgnoreCase("HDDMP")) {
			problem = new HDDMP(map);
		} else if(str.equalsIgnoreCase("WFG1")) {
			problem = new WFG1(map);
		} else if(str.equalsIgnoreCase("mWFG1")) {
			problem = new MinusWFG1(map);
		} else if(str.equalsIgnoreCase("nWFG1")) {
			problem = new NormalizedWFG1(map);
		} else if(str.equalsIgnoreCase("nmWFG1")) {
			problem = new NormalizedMinusWFG1(map);
		} else if(str.equalsIgnoreCase("WFG2")) {
			problem = new WFG2(map);
		} else if(str.equalsIgnoreCase("mWFG2")) {
			problem = new MinusWFG2(map);
		} else if(str.equalsIgnoreCase("nWFG2")) {
			problem = new NormalizedWFG2(map);
		} else if(str.equalsIgnoreCase("nmWFG2")) {
			problem = new NormalizedMinusWFG2(map);
		} else if(str.equalsIgnoreCase("WFG3")) {
			problem = new WFG3(map);
		} else if(str.equalsIgnoreCase("mWFG3")) {
			problem = new MinusWFG3(map);
		} else if(str.equalsIgnoreCase("nWFG3")) {
			problem = new NormalizedWFG3(map);
		} else if(str.equalsIgnoreCase("nmWFG3")) {
			problem = new NormalizedMinusWFG3(map);
		} else if(str.equalsIgnoreCase("WFG4")) {
			problem = new WFG4(map);
		} else if(str.equalsIgnoreCase("mWFG4")) {
			problem = new MinusWFG4(map);
		} else if(str.equalsIgnoreCase("nWFG4")) {
			problem = new NormalizedWFG4(map);
		} else if(str.equalsIgnoreCase("nmWFG4")) {
			problem = new NormalizedMinusWFG4(map);
		} else if(str.equalsIgnoreCase("WFG5")) {
			problem = new WFG5(map);
		} else if(str.equalsIgnoreCase("WFG6")) {
			problem = new WFG6(map);
		} else if(str.equalsIgnoreCase("WFG7")) {
			problem = new WFG7(map);
		} else if(str.equalsIgnoreCase("WFG8")) {
			problem = new WFG8(map);
		} else if(str.equalsIgnoreCase("WFG9")) {
			problem = new WFG9(map);
		}else if(str.equalsIgnoreCase("CSI") || str.equalsIgnoreCase("CarSideImpact")) { //Car-side impact problem
			problem = new CarSideImpactProblem(map);
		}
		else {
			System.err.println("Not found!: " + str);
			System.exit(-1);
		}
		return problem;
	}

}
