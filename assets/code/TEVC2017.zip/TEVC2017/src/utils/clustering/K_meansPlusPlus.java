package utils.clustering;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import utils.PseudoRandomGenerator;
import utils.calculation.MathCalculation;

public class K_meansPlusPlus {

	int numberOfdata;
	int numberOfClusters;
	int numberOfDimensions;
	ArrayList<ArrayList<Double>> data;
	double[][] centroidOfCluster;
	int[] clusterIndexOfData;
	boolean finishFlag;
	int cn;
	int seed;

	//Constructor
	K_meansPlusPlus(String fileName, int seed) {
		this.data = new ArrayList<>();
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				data.add(refPoint);
			}
			br.close();
			fr.close();

			this.seed = seed;

			Random rnd = new Random(this.seed);

			Collections.shuffle(data, rnd);

			this.numberOfdata = data.size();
			assert(this.numberOfdata>0);
			assert(this.data.get(0).size()>0);

			this.clusterIndexOfData = new int[this.numberOfdata];
			this.numberOfDimensions = this.data.get(0).size();

		} catch (IOException e) {
			System.err.println(e);
		}
	}


	//initilizer
	void initialize() {
		assert(this.numberOfClusters > 0);
		assert(this.numberOfDimensions > 0);
		assert(this.numberOfdata > 0);
		this.centroidOfCluster = new double[this.numberOfClusters][this.numberOfDimensions];

		int firstIndex = PseudoRandomGenerator.randInt(0, this.numberOfdata);

		for(int i = 0; i < this.numberOfDimensions; i++) {
			this.centroidOfCluster[0][i] = this.data.get(firstIndex).get(i);
			//this.centroidOfCluster[0][i] = 1.0 / this.numberOfDimensions;
		}

		double[] distance = new double[this.numberOfdata];

		for(int i = 1; i < this.numberOfClusters; i++) {
			for(int j = 0; j < this.numberOfdata; j++)
				distance[j] = calculateMinimumDistance(this.centroidOfCluster, this.data.get(j), i);

			int index = rouletteSelection(distance);
			assert(index >= 0);
			assert(index < this.numberOfdata);
			for(int j = 0; j < this.numberOfDimensions; j++)
				this.centroidOfCluster[i][j] = this.data.get(index).get(j);
		}

		try {
			File file = new File("InitialCentroids_r" + seed + "_m" + centroidOfCluster[0].length + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

				for(int i = 0; i < centroidOfCluster.length; i++) {
					for(int j = 0; j < centroidOfCluster[i].length; j++) {
						pw.print(centroidOfCluster[i][j]);
						if(j < centroidOfCluster[i].length - 1)
							pw.print(" ");
					}
					pw.println();
				}
			pw.close();
		} catch (IOException e) {
			System.exit(-1);
		}
	}


	double calculateMinimumDistance(double[][] centroids, ArrayList<Double> lambda, int numberOfCentroids) {
		assert(centroids.length > 0);
		assert(numberOfCentroids > 0);
		double minDistance = Double.MAX_VALUE;

		for(int i = 0, n = numberOfCentroids + 1; i < n; i++) {
			//double distance = MathCalculation.calculateEuclideanDistance(lambda, centroids[i]);
			double distance = Math.pow(MathCalculation.calculateEuclideanDistance(lambda, centroids[i]), 2);
			if(minDistance > distance)
				minDistance = distance;
		}
		return minDistance;
	}


	int rouletteSelection(double[] values) {
		double sumOfValues = 0.0;
		for(int i = 0, n = values.length; i < n; i++)
			sumOfValues += values[i];

		double[] probabilities = new double[values.length + 1];
		for(int i = 0, n = probabilities.length; i < n; i++) {
			for(int j = 0; j < i; j++) {
				probabilities[i] += values[j];
			}
			probabilities[i] /= sumOfValues;
		}

		int index = -1;
		double maxProb = Double.MIN_VALUE;
		for(int i = 0; i < values.length; i++) {
			double val = values[i];
			if(maxProb < val) {
				maxProb = val;
				index = i;
			}
		}

		double rndValue = PseudoRandomGenerator.randDouble();
		for(int i = 0, n = probabilities.length; i < n - 1; i++) {
			if((probabilities[i] <= rndValue) && (rndValue < probabilities[i+1])) {
				return i;
			}
		}
		return index;
	}


	//Assignment cluster to each data
	void clusterAssignment() {
		double distance;
		double minDistance;
		int index;
		assert(this.data.size()>0);
		assert(this.data.get(0).size()>0);
		ArrayList<ArrayList<Double>> r = new ArrayList<>();
		for(int i = 0, n = this.data.size(); i < n; i++) {
			ArrayList<Double> ri = new ArrayList<>();
			for(int j = 0, nj = this.data.get(i).size(); j < nj; j++) {
				ri.add(this.data.get(i).get(j));
			}
			r.add(ri);
		}

		assert(this.centroidOfCluster.length>0);
		assert(this.centroidOfCluster[0].length>0);
		double[][] x = new double[this.centroidOfCluster.length][this.numberOfDimensions];
		for(int i = 0; i < x.length; i++) {
			for(int j = 0; j < x[i].length; j++) {
				x[i][j] = this.centroidOfCluster[i][j];
			}
		}

		assert(this.numberOfClusters > 0);
		assert(this.numberOfdata > 0);

		for(int i = 0, n = r.size(); i < n; i++) {
			minDistance = Double.MAX_VALUE;
			index = -1;
			for(int j = 0; j < x.length; j++) {
				//distance = MathCalculation.calculateEuclideanDistance(r.get(i), x[j]);
				distance = Math.pow(MathCalculation.calculateEuclideanDistance(r.get(i), x[j]), 2);
				if(distance < minDistance) {
					minDistance = distance;
					index = j;
				}
			}
			if(this.clusterIndexOfData[i] != index) this.finishFlag = false;
			this.clusterIndexOfData[i] = index;
		}
	}


	void setNumberOfClusters(int myu) {
		this.numberOfClusters = myu;
	}


	void calculateClusterCentroid(int clusterIndex) {
		int index = clusterIndex;

		ArrayList<ArrayList<Double>> r = new ArrayList<>();
		for(int i = 0, n = this.data.size(); i < n; i++) {
			if(this.clusterIndexOfData[i]!=index) continue;
			ArrayList<Double> ri = new ArrayList<>();
			for(int j = 0, nj = this.data.get(i).size(); j < nj; j++) {
				ri.add(this.data.get(i).get(j));
			}
			r.add(ri);
		}
		if(r != null && r.size() != 0)
			this.centroidOfCluster[index] = MathCalculation.calculateCentroid(r, this.numberOfDimensions);
	}


	public double[][] execute(int numberOfClusters, int seed) {

		System.out.println("execute");

		setNumberOfClusters(numberOfClusters);
		initialize();
		clusterAssignment();

		do {
			this.cn = 0;
			this.finishFlag = true;
			for(int i = 0; i < this.numberOfClusters; i++) {
				calculateClusterCentroid(i);
			}
			clusterAssignment();
			System.out.println("update");
		} while(!this.finishFlag);

		return this.centroidOfCluster;
	}


	public static void main(String[] args) throws ClassNotFoundException {

		System.out.println("start"); /////

		int numberOfClusters = 10;
		String fileName = "m3_100000ref.csv";  // name of the file of the reference points used in K-means++
		int seed = 1;
		if((args.length%2 == 0) && (args.length > 0)) {
			for(int i = 0; i < args.length; i++) {
				if(args[i].equalsIgnoreCase("-pop")) {
					numberOfClusters = Integer.parseInt(args[i+1]);
				} else if(args[i].equalsIgnoreCase("-fn")) {
					fileName = args[i+1];
				} else if(args[i].equalsIgnoreCase("-run")) {
					seed = Integer.parseInt(args[i+1]);
				}
			}
		}

		PseudoRandomGenerator.setSeed(seed+1);
		K_meansPlusPlus k_means = new K_meansPlusPlus(fileName, seed);
		double[][] solutionSet = k_means.execute(numberOfClusters, seed);

		if(solutionSet.length == 0) return;

		try {
			File file = new File("FUN_r" + seed + "_m" + solutionSet[0].length + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

				for(int i = 0; i < solutionSet.length; i++) {
					for(int j = 0; j < solutionSet[i].length; j++) {
						//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
						pw.print(solutionSet[i][j]);
						if(j < solutionSet[i].length - 1)
							pw.print(" ");
					}
					pw.println();
				}
			pw.close();
		} catch (IOException e) {
			System.exit(-1);
		}

		System.out.println("finish");

	}
}
