package utils;

import core.Algorithm;
import core.Problem;
import emoa.smsemoa.SMSEMOA_IGD;

public class AlgorithmSelector {

	public AlgorithmSelector() {

	}


	public static Object getAlgorithm(String str, Problem problem) {
		Algorithm algorithm;

		if(str.equalsIgnoreCase("SMSEMOA_IGD")) {
			algorithm = new SMSEMOA_IGD(problem);
		} else {
			algorithm = null;
		}

		return algorithm;
	}

}
