package utils.calculation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import core.Solution;

public class SolutionSetSorting {

	public SolutionSetSorting() {
		//do nothing.
	}

	public void sort(ArrayList<Solution> set, Comparator comparator) {
		if (comparator == null) {
			return;
		} // if

		Collections.sort(set, comparator);
	} // sort
}
