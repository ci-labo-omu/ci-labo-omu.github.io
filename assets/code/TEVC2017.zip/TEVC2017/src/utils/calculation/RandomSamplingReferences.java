package utils.calculation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import core.Solution;
import utils.PseudoRandomGenerator;

public class RandomSamplingReferences {

	public static void main(String[] args) throws IOException {

		int numberOfObjectives = 3;
		int numberOfReferences = 10000;
		String TypeOfRandom = "simplex";
		int seed = 1;
		boolean inverse = false;

		if((args.length%2 == 0) && (args.length > 0)) {
			for(int i = 0; i < args.length; i++) {
				if(args[i].equalsIgnoreCase("-m")) {
					numberOfObjectives = Integer.parseInt(args[i+1]);
				} else if(args[i].equalsIgnoreCase("-ref")) {
					numberOfReferences = Integer.parseInt(args[i+1]);
				} else if(args[i].equalsIgnoreCase("-sha")) {
					TypeOfRandom = args[i+1];
				} else if(args[i].equalsIgnoreCase("-run")) {
					seed = Integer.parseInt(args[i+1]);
				} else if(args[i].equalsIgnoreCase("-inv")) {
					inverse = Boolean.parseBoolean(args[i+1]);
				}
			}
		}

		PseudoRandomGenerator.setSeed(seed+1);

		ArrayList<Solution> solutionSet = new ArrayList<>();
		initialize(solutionSet, numberOfReferences, numberOfObjectives);

		if(TypeOfRandom.equalsIgnoreCase("simplex")) {
			setNormalizedSimplex(solutionSet);
		} else if(TypeOfRandom.equalsIgnoreCase("sphere")) {
			setSphere(solutionSet);
		}

		if(inverse) inverseSols(solutionSet);

		File file = new File("reference_" + numberOfReferences + ".csv");
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		for(int i = 0; i < solutionSet.size(); i++) {
			for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
				//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
				pw.print(solutionSet.get(i).getObjective(j));
				if(j < solutionSet.get(i).getObjectives().length - 1)
					pw.print(",");
			}
			pw.println();
		}

	pw.close();

	}

	static void inverseSols(ArrayList<Solution> sols) {
		for(int i = 0; i < sols.size(); i++) {
			for(int j = 0, m = sols.get(i).getNumberOfObjectives(); j < m; j++) {
				sols.get(i).setObjective(j, 1.0 - sols.get(i).getObjective(j));
			}
		}
	}


	static void initialize(ArrayList<Solution> sols, int numberOfReferences, int numberOfObjectives) {
		for(int i = 0; i < numberOfReferences; i++) {
			Solution s = new Solution(numberOfObjectives, numberOfObjectives, "Real");
			for(int j = 0; j < numberOfObjectives; j++) {
				s.setVariable(j, PseudoRandomGenerator.randDouble());
				s.setLowerbound(j, 0.0);
				s.setUpperbound(j, 1.0);
			}
			sols.add(s);
		}
		assert(sols.size() == numberOfReferences);
	}


	static void setNormalizedSimplex(ArrayList<Solution> sols) {
		if(sols.size() == 0 || sols.get(0).getObjectives().length == 0) return;

		double value = 0.0;
		for(int i = 0, n = sols.size(); i < n; i++) {
			double sum = 0.0;
			for(int j = 0, m = sols.get(i).getObjectives().length; j < m; j++) {
				value = Math.log(sols.get(i).getVariable(j));
				//value = sols.get(i).getVariable(j);
				sols.get(i).setObjective(j, value);
			}

			for(int j = 0,m = sols.get(i).getObjectives().length; j < m; j++) {
				sum += sols.get(i).getObjective(j);
			}

			for(int j = 0, m = sols.get(i).getObjectives().length; j < m; j++) {
				sols.get(i).setObjective(j, sols.get(i).getObjective(j) / sum);
			}
		}
	}


	static void setSphere(ArrayList<Solution> sols) {
		if(sols.size() == 0 || sols.get(0).getObjectives().length == 0) return;

		double c = 0.0;
		double mean = 0.0, variance = 1.0;
		double value = 0.0, sum = 0.0;
		boolean skip = false;
		for(int i = 0; i < sols.size(); i++) {
			skip = false;
			for(int j = 0, m = sols.get(i).getNumberOfObjectives(); j < m; j++) {
				c = Math.sqrt(-2.0*Math.log(PseudoRandomGenerator.randDouble()));
				if (PseudoRandomGenerator.randDouble() < 0.5) {
		            sols.get(i).setObjective(j, c * Math.sin(2.0 * Math.PI * PseudoRandomGenerator.randDouble()) * variance + mean);
		        } else {
		        	sols.get(i).setObjective(j, c * Math.cos(2.0 * Math.PI * PseudoRandomGenerator.randDouble()) * variance + mean);
		        }
				if(sols.get(i).getObjective(j) < 0.0) {
					skip = true;
					continue;
				}
			}
			if(skip) {
				i--;
				continue;
			}
			sum = 0.0;
			for(int j = 0, m = sols.get(i).getNumberOfObjectives(); j < m; j++) sum += Math.pow(sols.get(i).getObjective(j), 2.0);
			sum = Math.sqrt(sum);
			for(int j = 0, m = sols.get(i).getNumberOfObjectives(); j < m; j++)
				sols.get(i).setObjective(j, sols.get(i).getObjective(j)/sum);
		}
	}

}
