package utils.calculation;

import core.Solution;

public class EuclidianDistanceCalculation {

	public EuclidianDistanceCalculation(){}

	public double getDistance(Solution s1, Solution s2) {
		double dist = 0.0;
		if(s1.getNumberOfObjectives()!=s2.getNumberOfObjectives()) {
			System.err.println("nObj must be the same!!");
			System.exit(-1);
		}
		for(int ob = 0, nObj = s1.getNumberOfObjectives(); ob < nObj; ob++)
			dist += (s1.getObjective(ob)-s2.getObjective(ob)) * (s1.getObjective(ob)-s2.getObjective(ob));
		return dist;
	}


	public double getDistance(Solution s1, double[] s2) {
		double dist = 0.0;
		if(s1.getNumberOfObjectives()!=s2.length) {
			System.err.println("nObj must be the same!!");
			System.exit(-1);
		}
		for(int ob = 0, nObj = s1.getNumberOfObjectives(); ob < nObj; ob++)
			dist += (s1.getObjective(ob)-s2[ob]) * (s1.getObjective(ob)-s2[ob]);
		return dist;
	}


	public double getDistance(double[] s1, double[] s2) {
		double dist = 0.0;
		if(s1.length!=s2.length) {
			System.err.println("nObj must be the same!!");
			System.exit(-1);
		}
		for(int ob = 0, nObj = s1.length; ob < nObj; ob++)
			dist += (s1[ob]-s2[ob]) * (s1[ob]-s2[ob]);
		return dist;
	}
}
