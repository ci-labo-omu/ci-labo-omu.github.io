package utils.calculation;

import java.util.ArrayList;

import core.Solution;

public class ScalarizingFunction {
	String functionName_;

	public ScalarizingFunction(String name) {
		functionName_ = name;
	}

	public double calculate(Solution s, ArrayList<Double> w, double[] z, double[] n, double theta) {
		double scalar = 0.0;
		if(functionName_.equalsIgnoreCase("WS")) {
			scalar = weightedSum(s, w);
		} else if(functionName_.equalsIgnoreCase("TCHE")) {
			scalar = tchebycheff(s, w, z);
		} else if(functionName_.equalsIgnoreCase("mTCHE")) {
			scalar = modifiedTchebycheff(s, w, z);
		} else if(functionName_.equalsIgnoreCase("rTCHE")) {
			scalar = replacedTchebycheff(s, w, z);
		} else if(functionName_.equalsIgnoreCase("PBI")) {
			scalar = penaltyBasedBoundaryIntersection(s, w, z, theta);
		} else if(functionName_.equalsIgnoreCase("IPBI")) {
			scalar = invertedPenaltyBasedBoundaryIntersection(s, w, n, theta);
		}
		return scalar;
	}

	public double weightedSum(Solution s, ArrayList<Double> w) {
		double scalar = 0.0;
		for(int i = 0, size = w.size(); i < size; i++) scalar += w.get(i) * s.getObjective(i);
		return scalar;
	}

	public double tchebycheff(Solution s, ArrayList<Double> w, double[] z) {
		double maxValue = -Double.MAX_VALUE;
		for(int i = 0, size = w.size(); i < size; i++) {
			double value = w.get(i) * Math.abs(s.getObjective(i) - z[i]);
			if(maxValue < value) maxValue = value;
		}
		return maxValue;
	}

	public double modifiedTchebycheff(Solution s, ArrayList<Double> w, double[] z) {
		double norm = 0.0;
		double EPSILON = 1.0 / 1.0e-6;
		double[] invZ = new double[w.size()];
		for(int i = 0, size = w.size(); i < size; i++) {
			if(w.get(i) == 0.0) {
				invZ[i] = EPSILON;
				norm += EPSILON;
				continue;
			}
			invZ[i] = 1.0 / w.get(i);
			norm += 1.0 / w.get(i);
		}
		double maxValue = -Double.MAX_VALUE;
		for(int i = 0, size = invZ.length; i < size; i++) {
			double value = Math.abs(s.getObjective(i) - z[i]) * invZ[i];
			if(maxValue < value) maxValue = value;
		}
		return maxValue;
	}

	public double replacedTchebycheff(Solution s, ArrayList<Double> w, double[] z) {
		double maxValue = -Double.MAX_VALUE;
		for(int i = 0, size = w.size(); i < size; i++) {
			double coefficient = w.get(i);
			if(coefficient <= 1.0e-6) coefficient = 1.0e-6;
			double value = coefficient * Math.abs(s.getObjective(i) - z[i]);
			if(maxValue < value) maxValue = value;
		}
		return maxValue;
	}

	public double penaltyBasedBoundaryIntersection(Solution s, ArrayList<Double> w, double[] z, double theta) {
		double dt = 0.0, dn = 0.0, norm = 0.0;
		int size = w.size();
		for(int i = 0; i < size; i++) {
			dt += (s.getObjective(i) - z[i]) * w.get(i);
			norm += MathCalculation.sq(w.get(i));
		}
		norm = Math.sqrt(norm);
		dt /= norm;
		for(int i = 0; i < size; i++) dn += MathCalculation.sq((s.getObjective(i) - z[i]) - dt * w.get(i) / norm);
		dn = Math.sqrt(dn);
		return Math.abs(dt) + theta * dn;
	}

	public double invertedPenaltyBasedBoundaryIntersection(Solution s, ArrayList<Double> w, double[] n, double theta) {
		double dt = 0.0, dn = 0.0, norm = 0.0;
		int size = w.size();
		for(int i = 0; i < size; i++) {
			dt += (n[i] - s.getObjective(i)) * w.get(i);
			norm += MathCalculation.sq(w.get(i));
		}
		norm = Math.sqrt(norm);
		dt /= norm;
		for(int i = 0; i < size; i++) dn += MathCalculation.sq((n[i] - s.getObjective(i)) - dt * w.get(i) / norm);
		dn = Math.sqrt(dn);
		return -(Math.abs(dt) - theta * dn);
	}
}
