package utils;

import utils.MTs.MersenneTwisterFast;

public class PseudoRandomGenerator {
	private static MersenneTwisterFast mt_ = null;
	private static int seed_ = 1;


	private PseudoRandomGenerator() {
		if(mt_ == null) {
			mt_ = new MersenneTwisterFast(seed_);
		}
	}


	public static void setSeed(int seed) {
		seed_ = seed;
		mt_ = new MersenneTwisterFast(seed_);
	}


	public static int randInt() {
		if(mt_ == null) {
			mt_ = new MersenneTwisterFast(seed_);
		}
		return mt_.nextInt(Integer.MAX_VALUE);
	}


	public static double randDouble() {
		if(mt_ == null) {
			mt_ = new MersenneTwisterFast(seed_);
		}
		return mt_.nextDoubleII();
	}


	public static int randInt(int minBound, int maxBound) {
		if(mt_ == null) {
			mt_ = new MersenneTwisterFast(seed_);
		}
		return minBound + mt_.nextInt(maxBound-minBound);
		//return minBound + randomJava.nextInt(maxBound-minBound+1);
	} // randInt


	public static double randDouble(double minBound, double maxBound) {
		if(mt_ == null) {
			mt_ = new MersenneTwisterFast(seed_);
		}
		return minBound + mt_.nextDoubleII() * (maxBound-minBound);
		//return minBound + (maxBound - minBound)*randomJava.nextDouble();
	} // randDouble

}
