package utils.ranking;

import java.util.ArrayList;

import core.Solution;

public interface Ranking {
	public ArrayList<Solution> getSubFront(int rank);
	public int getNumberOfSubFronts();
}
