package utils.ranking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;

import core.Solution;
import utils.comparator.ConstraintViolationComparator;
import utils.comparator.ParetoComparator;

public class NondominatedSort implements Ranking {

	ArrayList<ArrayList<Solution>> subFronts_;

	private static final Comparator dominate_ = new ParetoComparator();

	private static final Comparator CVdominate_ = new ConstraintViolationComparator();


	//Constructor
	public NondominatedSort(ArrayList<Solution> solutionSet) {

		subFronts_ = new ArrayList<ArrayList<Solution>>();

		ArrayList<Solution> front = new ArrayList<Solution>();

		int dominationFlag;

		for(int p = 0, n = solutionSet.size(); p < n; p++) {
			solutionSet.get(p).setDominatedCounter(0);
			solutionSet.get(p).resetDominatedSolutionSet();
		}

		for(int p = 0, n = solutionSet.size() - 1; p < n; p++) {
			for(int q = p + 1; q < n + 1; q++) {
				dominationFlag = CVdominate_.compare(solutionSet.get(p), solutionSet.get(q));
				if(dominationFlag == 0){
					dominationFlag = dominate_.compare(solutionSet.get(p), solutionSet.get(q));
				}
				if(dominationFlag == -1) {
					solutionSet.get(p).addDominatesSolutionSet(solutionSet.get(q));
					solutionSet.get(q).incrementDominatedCounter();
				} else if(dominationFlag == 1) {
					solutionSet.get(q).addDominatesSolutionSet(solutionSet.get(p));
					solutionSet.get(p).incrementDominatedCounter();
				}
			}

			//System.out.println("np: " + solutionSet.get(p).getDominatedCounter());

		}

		for(int p = 0, n = solutionSet.size(); p < n; p++) {
			if(solutionSet.get(p).getDominatedCounter() == 0) {
				solutionSet.get(p).setRank(0);
				front.add(solutionSet.get(p));
			}
		}

		subFronts_.add(front);

		int i = 0;
		int n;

		while((n = subFronts_.get(i).size()) != 0) {

			front = new ArrayList<Solution>();

			for(int p = 0; p < n; p++) {
				for(int q = 0, nq = subFronts_.get(i).get(p).getDominatesSolutionSet().size(); q < nq; q++) {
					subFronts_.get(i).get(p).getDominatesSolutionSet().get(q).decrementDominatedCounter();

					if(subFronts_.get(i).get(p).getDominatesSolutionSet().get(q).getDominatedCounter() == 0) {
						subFronts_.get(i).get(p).getDominatesSolutionSet().get(q).setRank(i + 1);
						front.add(subFronts_.get(i).get(p).getDominatesSolutionSet().get(q));
					}

				}
			}
			subFronts_.add(front);
			i++;
		}

	}


	@Override
	public ArrayList<Solution> getSubFront(int rank) {
		return subFronts_.get(rank);
	}


	@Override
	public int getNumberOfSubFronts() {
		return subFronts_.size();
	}


	public static void main(String[] args) throws IOException {
		String fileName = args[0];
		System.out.println(fileName);
		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));


		String str;
		ArrayList<Solution> solutionSet = new ArrayList<Solution>();

		while((str = br.readLine()) != null) {
			String[] data = str.split(",");
			Solution s = new Solution(2, data.length, "Real");

			for(int i = 0; i < data.length; i++) {
				s.setObjective(i, Double.parseDouble(data[i]));
			}
			solutionSet.add(s);
		}

		NondominatedSort ranking = new NondominatedSort(solutionSet);
		ArrayList<Solution> front = ranking.getSubFront(0);
		//ArrayList<Solution> front = solutionSet;


		String[] topStr = fileName.split(".csv");
//		System.out.println(topStr.length);
		String[] strArray = topStr[0].split("/");
		FileWriter fw = new FileWriter("./front_"+strArray[strArray.length-1]+".csv", false);
		PrintWriter pw = new PrintWriter(new BufferedWriter(fw));
		for(int i = 0; i < front.size(); i++) {
			//pw.print((front.get(i).getRank()+1) + "\t");
			for(int j = 0; j < front.get(i).getObjectives().length; j++) {
				pw.print(front.get(i).getObjective(j));
				if(j < front.get(i).getObjectives().length - 1) {
					pw.print(",");
				}
			}
			//pw.print("\t0.0");
			pw.println();
		}
		pw.close();
		fw.close();
	}

}
