package utils.vector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class IterativeWeightGenerator {

	double epsilon_ = 0.1;
	ArrayList<ArrayList<Double>> P_;
	ArrayList<ArrayList<Double>> Pdash_;
	ArrayList<ArrayList<Double>> Q_;
	int nWeights_;
	int nObjs_;
	ArrayList<Double> mappingPoint_;//(written as A' in the paper)

	//Constructor
	public IterativeWeightGenerator(double eps, int nWeights, ArrayList<Double> ref) {
		this.nWeights_ = nWeights;
		this.epsilon_ = eps;
		this.nObjs_ = ref.size();
		this.mappingPoint_ = normalization(ref);
		this.P_ = new ArrayList<>();
		this.Pdash_ = new ArrayList<>();
		this.Q_ = new ArrayList<>();
	}


	public ArrayList<ArrayList<Double>> execute() {
		Random rnd = new Random(this.nWeights_);
		this.Q_ = getBoundaryPoints();
		this.Q_.add(this.mappingPoint_);
		this.P_ = getMidPoints(this.Q_);
		MAIN_ROOP:
		while(!isTerminated(this.Q_.size())) {
			this.Pdash_ = getMidPoints(this.P_, this.Q_);
			this.Q_ = getMergeList(this.P_, this.Q_);
			System.out.println("P's size: " + this.P_.size());
			System.out.println("Pdash's size: " + this.Pdash_.size());
			System.out.println("Q's size: " + this.Q_.size());
			while(this.Q_.size() > this.nWeights_) {
				Collections.shuffle(this.Q_, rnd);
				this.Q_.remove(this.Q_.size()-1);
				if(this.Q_.size()==this.nWeights_) break MAIN_ROOP;
			}
			if(isTerminated(this.Q_.size())) break;
			this.P_ = getMidPoints(this.Pdash_, this.Q_);
//			this.Q_ = getMergeList(this.Pdash_, this.Q_);
			System.out.println("P's size: " + this.P_.size());
			System.out.println("Pdash's size: " + this.Pdash_.size());
			System.out.println("Q's size: " + this.Q_.size());
			while(this.Q_.size() > this.nWeights_) {
				Collections.shuffle(this.Q_, rnd);
				this.Q_.remove(this.Q_.size()-1);
				if(this.Q_.size()==this.nWeights_) break MAIN_ROOP;
			}
		}
		System.out.println("Output Q's size: " + this.Q_.size());
		return this.Q_;
	}


	//A point is normalized by this method. The normalized point is on the hyper-plane(f1+f2+...+fm=1).
	public ArrayList<Double> normalization(ArrayList<Double> point) {
		ArrayList<Double> nPoint = new ArrayList<>();
		double sum = 0.0;
		for(int ob = 0; ob < nObjs_; ob++) sum += point.get(ob);
		for(int ob = 0; ob < nObjs_; ob++) nPoint.add(point.get(ob)/sum);
		return nPoint;
	}

	//This method generate the boundary points of the mapping region.(B', C', D', ...)
	public ArrayList<ArrayList<Double>> getBoundaryPoints() {
		ArrayList<ArrayList<Double>> boundaryPoints = new ArrayList<>();
		for(int ob = 0; ob < nObjs_; ob++) {
			ArrayList<Double> boundaryPoint = new ArrayList<>();
			for(int obDash = 0; obDash < nObjs_; obDash++) {
				double value = 0.0;
				if(obDash==ob) value = this.epsilon_;
				value += (1.0 - this.epsilon_) * this.mappingPoint_.get(obDash);
				boundaryPoint.add(value);
			}
			boundaryPoints.add(boundaryPoint);
		}
		return boundaryPoints;
	}


	public ArrayList<ArrayList<Double>> getMidPoints(ArrayList<ArrayList<Double>> points) {
		ArrayList<ArrayList<Double>> midPoints = new ArrayList<>();
		for(int id = 0, size = points.size(); id < size-1; id++) {
			for(int idDash = id+1; idDash < size; idDash++) {
				ArrayList<Double> midPoint = new ArrayList<>();
				for(int ob = 0; ob < nObjs_; ob++)
					midPoint.add((points.get(id).get(ob)+points.get(idDash).get(ob))*0.5);
				midPoints.add(midPoint);
			}
		}
		return midPoints;
	}


	public ArrayList<ArrayList<Double>> getMidPoints(ArrayList<ArrayList<Double>> P, ArrayList<ArrayList<Double>> Q) {
		ArrayList<ArrayList<Double>> midPoints = new ArrayList<>();
		for(int id = 0, sizeP = P.size(); id < sizeP; id++) {
			for(int idDash = 0, sizeQ = Q.size(); idDash < sizeQ; idDash++) {
				ArrayList<Double> midPoint = new ArrayList<>();
				for(int ob = 0; ob < nObjs_; ob++)
					midPoint.add((P.get(id).get(ob)+Q.get(idDash).get(ob))*0.5);
				midPoints.add(midPoint);
			}
		}
		return midPoints;
	}


	boolean isTerminated(int size) {
		return size >= this.nWeights_;
	}


	public ArrayList<ArrayList<Double>> getMergeList(ArrayList<ArrayList<Double>> P, ArrayList<ArrayList<Double>> Q) {
		ArrayList<ArrayList<Double>> mergedList = new ArrayList<>();
		for(int id = 0; id < P.size(); id++) {
			ArrayList<Double> point = new ArrayList<>();
			for(int ob = 0; ob < this.nObjs_; ob++) {
				point.add(P.get(id).get(ob));
			}
			mergedList.add(point);
		}
		for(int id = 0; id < Q.size(); id++) {
			ArrayList<Double> point = new ArrayList<>();
			for(int ob = 0; ob < this.nObjs_; ob++) {
				point.add(Q.get(id).get(ob));
			}
			mergedList.add(point);
		}
		return mergedList;
	}

}
