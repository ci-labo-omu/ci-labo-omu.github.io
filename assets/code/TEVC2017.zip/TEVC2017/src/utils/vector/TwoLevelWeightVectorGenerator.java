package utils.vector;

import java.util.ArrayList;

public class TwoLevelWeightVectorGenerator extends VectorGenerator {
	int div1;
	int div2;
	int m_;
	boolean inverse_;


	static int gn;

	public TwoLevelWeightVectorGenerator(int div1, int div2, int m, boolean inverse){
		this.div1 = div1;
		this.div2 = div2;
		this.m_ = m;
		this.inverse_ = inverse;

		int N1 = 0;
		int N2 = 0;
		if (div1 != 0){
			N1 = getCombin(m_ + div1 - 1, div1);
		}
		if (div2 != 0){
			N2 = getCombin(m_ + div2 - 1, div2);
		}

		double[][] z1 = null;
		double[][] z2 = null;

		lambda_ = new ArrayList<ArrayList<Double>>();

		if (N1 != 0)
			z1 = new double[N1][m_];
		if (N2 != 0)
			z2 = new double[N2][m_];

		//System.out.println(N1);
		//System.out.println(N2);
		if (N1 != 0)
			generateWeightVector(z1, div1, m_);
		if (N2 != 0)
			generateWeightVector(z2, div2, m_);

		double mid = 1.0 / m_;
		for (int i = 0; i < N2; i++){
			for (int j = 0; j < m_; j++){
				z2[i][j] = (z2[i][j] + mid) / 2;
			}
		}

		if(inverse_) {
			if(N1 != 0)
				inverseVector(z1);
			if(N2 != 0)
				inverseVector(z2);
		}

		for (int i = 0; i < N1; i++){
			ArrayList<Double> w = new ArrayList<>();
			for (int j = 0; j < m_; j++)
				w.add(z1[i][j]);
			lambda_.add(w);
		}

		for (int i = 0; i < N2; i++){
			ArrayList<Double> w = new ArrayList<>();
			for (int j = 0; j < m_; j++)
				w.add(z2[i][j]);
			lambda_.add(w);
		}
	}


	public TwoLevelWeightVectorGenerator(int div1, int div2, int m, boolean inverse, double alpha){
		this.div1 = div1;
		this.div2 = div2;
		this.m_ = m;
		this.inverse_ = inverse;

		int N1 = 0;
		int N2 = 0;
		if (div1 != 0){
			N1 = getCombin(m_ + div1 - 1, div1);
		}
		if (div2 != 0){
			N2 = getCombin(m_ + div2 - 1, div2);
		}

		double[][] z1 = null;
		double[][] z2 = null;

		lambda_ = new ArrayList<ArrayList<Double>>();

		if (N1 != 0)
			z1 = new double[N1][m_];
		if (N2 != 0)
			z2 = new double[N2][m_];

		//System.out.println(N1);
		//System.out.println(N2);
		if (N1 != 0)
			generateWeightVector(z1, div1, m_);
		if (N2 != 0)
			generateWeightVector(z2, div2, m_);

		double mid = 1.0 / m_;
		for (int i = 0; i < N2; i++){
			for (int j = 0; j < m_; j++) z2[i][j] = (1.0 - alpha) * z2[i][j] + alpha * mid;
		}

		if(inverse_) {
			if(N1 != 0)
				inverseVector(z1);
			if(N2 != 0)
				inverseVector(z2);
		}

		for (int i = 0; i < N1; i++){
			ArrayList<Double> w = new ArrayList<>();
			for (int j = 0; j < m_; j++)
				w.add(z1[i][j]);
			lambda_.add(w);
		}

		for (int i = 0; i < N2; i++){
			ArrayList<Double> w = new ArrayList<>();
			for (int j = 0; j < m_; j++)
				w.add(z2[i][j]);
			lambda_.add(w);
		}
	}

	public double[][] inverseVector(double[][] lambda) {
		assert lambda.length >= 0 : "No element in lambda_!";
		if(lambda.length == 0) return lambda;
		for(int i = 0; i < lambda.length; i++) {
			assert lambda[i].length == this.m_ : "i-th lambda's length is wrong!";
			for(int j = 0; j < this.m_; j++) lambda[i][j] = 1.0 - lambda[i][j];
		}
		return lambda;
	}

	public static int getCombin(int n, int m) {
		if (m == 0)
			return 1;
		if (m > n / 2)
			m = n - m;
		int res = 1;
		for (int k = 1; k <= m; k++)
			res = (n - k + 1) * res / k;
		return res;
	}


	public void generateWeightVector(double[][] z, int divisions, int m) {

		int[] tr = new int[m];

		gn = 0;

		Traverse(z, tr, m, 0, divisions);

		for (int i = 0; i < z.length; i++) {
			for (int j = 0; j < z[i].length; j++) {
				z[i][j] = (double) z[i][j] / divisions;
			}
		}


	}

	static void Traverse(double[][] z, int[] tr, int m, int i, int divisions) {
		if (i == (m - 1)) {
			tr[i] = divisions;
			for (int k = 0; k < m; k++) {
				z[gn][k] = tr[k];
			}
			gn++;
			return;
		}

		for (int k = 0; k <= divisions; k++) {
			tr[i] = k;
			Traverse(z, tr, m, i + 1, divisions - k);
		}

	}


	public static void main(String args[]){
/*		WeightVectorGeneratorV3 wv = new WeightVectorGeneratorV3(8, 0, 8);

		System.out.println(wv.lambda_.length);


		double[][] lambda = wv.lambda_;

		System.out.println(lambda.length);
		for (int i = 0; i < lambda.length; i++){
			if (lambda[i][0] == 0  || lambda[i][1] == 0
					|| lambda[i][2] == 0 || lambda[i][3] == 0
					|| lambda[i][4] == 0 || lambda[i][5] == 0
					|| lambda[i][6] == 0 || lambda[i][7] == 0)
				continue;
			for (int j = 0; j < lambda[i].length; j++){
				System.out.print(lambda[i][j] + "\t");
			}

		//	System.out.println();
			System.out.println();
		}*/


		System.out.println(String.format("%E", Math.pow(10, -1)));

	}
}
