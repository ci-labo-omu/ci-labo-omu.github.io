package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class BinaryTournamentComparator implements Comparator<Object> {

	private Comparator dominate_ = new ParetoComparator();
	private Comparator comparator_ = new CrowdingDistanceComparator();


	public BinaryTournamentComparator() {}


	public BinaryTournamentComparator(Comparator comp) {
		this.comparator_ = comp;
	}


	@Override
	public int compare(Object o1, Object o2) {
		int rank1, rank2;
	    rank1 = ((Solution)o1).getRank();
	    rank2 = ((Solution)o2).getRank();
	    double CV1, CV2;
	    CV1 = ((Solution)o1).getConstraintViolation();
	    CV2 = ((Solution)o2).getConstraintViolation();
	    if(CV1 > 0.0 && CV2 <= 0.0) {
	    	return 1;
	    } else if(CV1 <= 0.0 && CV2 > 0.0){
	    	return -1;
	    }
	    if(rank1 < rank2) {
	    	return -1;
	    } else if(rank1 > rank2) {
	    	return 1;
	    } else {
	    	return comparator_.compare(o1, o2);
	    }
	}
}
