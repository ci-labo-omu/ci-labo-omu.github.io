package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class AttributeValueComparator implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {
		double attr1 = ((Solution)o1).getAttributeValue();
		double attr2 = ((Solution)o2).getAttributeValue();

		return (int) Math.signum(attr2-attr1);
	}

}
