package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class SolIDComparator implements Comparator<Object> {

	boolean ascending_ = true;

	public SolIDComparator(boolean ascend) {
		this.ascending_ = ascend;
	}

	public void setAscending(boolean ascend) {
		this.ascending_ = ascend;
	}

	@Override
	public int compare(Object o1, Object o2) {
		if(o1 == null) return 1;
		if(o2 == null) return -1;
		int cd1 = ((Solution)o1).getIndividualNumber();
		int cd2 = ((Solution)o2).getIndividualNumber();

		if(ascending_) {
			return (int) Math.signum(cd1-cd2);
		} else {
			return (int) Math.signum(cd2-cd1);
		}
	}

}
