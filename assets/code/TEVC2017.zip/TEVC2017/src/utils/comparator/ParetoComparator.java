package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class ParetoComparator implements Comparator<Solution>{

	private static String optimize_ = "min";


	public static void setOptimize(String optimize) {
		optimize_ = optimize;
	}

	@Override
	public int compare(Solution o1, Solution o2) {
		int m = o1.getObjectives().length;
		int f1 = 0;
		int f2 = 0;
		if(this.optimize_.equalsIgnoreCase("min")) {
			for(int i = 0; i < m; i++) {
				if(o1.getObjective(i) < o2.getObjective(i)) {
					f1 = 1;
				} else if(o1.getObjective(i) > o2.getObjective(i)) {
					f2 = 1;
				}
			}
			if(f1 == f2) {
				return 0;
			} else if(f1 == 1) {
				return -1;
			} else {
				return 1;
			}

		} else if(this.optimize_.equalsIgnoreCase("max")) {
			for(int i = 0; i < m; i++) {
				if(o1.getObjective(i) > o2.getObjective(i)) {
					f1 = 1;
				} else if(o1.getObjective(i) < o2.getObjective(i)) {
					f2 = 1;
				}
			}
			if(f1 == f2) {
				return 0;
			} else if(f1 == 1) {
				return -1;
			} else {
				return 1;
			}

		} else {
			return 0;
		}
	}
}
