package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class ObjectiveComparator implements Comparator<Object> {

	int objectiveIndex_;
	boolean ascendingOrder_;


	//Constructor
	public ObjectiveComparator(int index) {
		this.objectiveIndex_ = index;
		this.ascendingOrder_ = true;
	}


	//Constructor
	public ObjectiveComparator(int index, boolean order) {
		this.objectiveIndex_ = index;
		this.ascendingOrder_ = order;
	}


	@Override
	public int compare(Object o1, Object o2) {
		if(o1 == null) return 1;
		if(o2 == null) return -1;

		double var1 = ((Solution) o1).getObjective(this.objectiveIndex_);
		double var2 = ((Solution) o2).getObjective(this.objectiveIndex_);

		if(this.ascendingOrder_) {
			if(var1 < var2) {
				return -1;
			} else if(var1 > var2) {
				return 1;
			} else {

				int id1 = ((Solution) o1).getIndividualNumber();
				int id2 = ((Solution) o2).getIndividualNumber();

				if(id1 < id2) {
					return -1;
				} else if(id1 > id2) {
					return 1;
				} else {
					return 0;
				}
			}
		} else {
			if(var1 < var2) {
				return 1;
			} else if(var1 > var2) {
				return -1;
			} else {

				int id1 = ((Solution) o1).getIndividualNumber();
				int id2 = ((Solution) o2).getIndividualNumber();

				if(id1 < id2) {
					return -1;
				} else if(id1 > id2) {
					return 1;
				} else {
					return 0;
				}
			}
		}
	}

}
