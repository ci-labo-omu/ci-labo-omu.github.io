package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class ConstraintViolationComparator implements Comparator<Solution> {

	@Override
	public int compare(Solution s1, Solution s2) {
		double cv1 = s1.getConstraintViolation();
		double cv2 = s2.getConstraintViolation();
		if(cv1 > 0 && cv2 > 0) {
			if(cv1 - cv2 < 0) {
				return -1;
			} else if(cv1 - cv2 > 0) {
				return 1;
			} else {
				return 0;
			}
		} else if(cv1 == 0 && cv2 > 0) {
			return -1;
		} else if(cv1 > 0 && cv2 == 0){
			return 1;
		} else {
			return 0;
		}
	}

}
