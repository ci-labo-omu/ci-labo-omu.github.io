package core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Algorithm {

	protected Problem problem_;

	protected Map<String, Operator> operators_ = null;

	protected Map<String, Object> inputParameters_ = null;

	protected Map<String, Object> outputParameters_ = null;


	//Constructor
	public Algorithm(Problem problem) {
		this.problem_ = problem;
	}


	abstract public void setting();

	//Execution of a some algorithm.
	public abstract ArrayList<Solution> execute() throws ClassNotFoundException;


	//Adds an operator.
	public void addOperator(String name, Operator operator) {
		if(this.operators_ == null) {
			this.operators_ = new HashMap<String, Operator>();
		}
		this.operators_.put(name, operator);
	}


	//Gets an operator.
	public Operator getOperator(String name) {
		return this.operators_.get(name);
	}


	//Adds an input parameter.
	public void addInputParameter(String name, Object object) {
		if(this.inputParameters_ == null) {
			this.inputParameters_ = new HashMap<String, Object>();
		}
		this.inputParameters_.put(name, object);
	}


	//Gets an input parameter.
	public Object getInputParameter(String name) {
		return this.inputParameters_.get(name);
	}


	//Adds an output parameter.
	public void addOutputParameter(String name, Object object) {
		if(this.outputParameters_ == null) {
			this.outputParameters_ = new HashMap<String, Object>();
		}
		this.outputParameters_.put(name, object);
	}


	//Gets an output parameter.
	public Object getOutputParameter(String name) {
		return this.outputParameters_.get(name);
	}

}
