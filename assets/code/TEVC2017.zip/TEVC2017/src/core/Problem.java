package core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class Problem {

	private final static int DEFAULT_PRECISION = 16;

	protected int numberOfVariables_;

	protected int numberOfObjectives_;

	protected String solutionType_;

	protected int numberOfConstraints_;

	protected String problemName_;

	protected double[] lowerBounds_;

	protected double[] upperBounds_;

	private int[] precision_;

	private int[] length_;

	protected Map<String, Object> inputParameters_ = null;

	//Constructor
	public Problem() {
		this.solutionType_ = null;
	}

	//Constructor
	public Problem(HashMap<String, Object> map) {
		this.inputParameters_ = map;
		this.numberOfVariables_ = (Integer)this.getInputParameter("numberOfVariables");
		this.numberOfObjectives_ = (Integer)this.getInputParameter("numberOfObjectives");
		this.numberOfConstraints_ = (Integer)this.getInputParameter("numberOfConstraints");

		this.lowerBounds_ = new double[this.numberOfVariables_];
		this.upperBounds_ = new double[this.numberOfVariables_];
	}


	//Evaluation of the objective values of a solution.
	public abstract void evaluate(Solution solution) throws ClassNotFoundException;


	//Evaluation of the constraint value of a solution.
	public void evaluateConstraintViolation(Solution solution) {
		//The default behaivor is to do nothing.
	}


	//Gets the number of variables.
	public int getNumberOfVariables() {
		return this.numberOfVariables_;
	}


	//Gets the number of variables.
	public int getNumberOfObjectives() {
		return this.numberOfObjectives_;
	}


	public String getSolutionType() {
		return this.solutionType_;
	}


	//Gets the number of variables.
	public int getNumberOfConstraints() {
		return this.numberOfConstraints_;
	}


	//Gets the name of the problem.
	public String getProblemName() {
		return this.problemName_;
	}


	//Gets the lowerbound value of i-th variables.
	public double getLowerBound(int index) {
		return this.lowerBounds_[index];
	}


	//Gets the upperbound value of i-th variables.
	public double getUpperBound(int index) {
		return this.upperBounds_[index];
	}


	//Gets the length of variable.
	public int getLength(int index) {
		if(this.length_ == null) {
			return DEFAULT_PRECISION;
		}
		return length_[index];
	}


	public int getPrecision(int index) {
		return this.precision_[index];
	}


	public int[] getPrecision() {
		return this.precision_;
	}


	public void setPrecision(int[] precision) {
		this.precision_ = precision;
	}


	//Adds an input parameter.
	public void addInputParameter(String name, Object object) {
		if(this.inputParameters_ == null) {
			this.inputParameters_ = new HashMap<String, Object>();
		}
		this.inputParameters_.put(name, object);
	}


	//Gets an input parameter.
	public Object getInputParameter(String name) {
		return this.inputParameters_.get(name);
	}


	public ArrayList<Solution> getParetoSets(int nSols) {
		ArrayList<Solution> sols = new ArrayList<>();
		return sols;
	}


	public ArrayList<Solution> getKneeSets() {
		ArrayList<Solution> knees = new ArrayList<>();
		return knees;
	}

}
