package runner;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import core.Algorithm;
import core.Operator;
import core.Problem;
import core.Solution;
import utils.AlgorithmSelector;
import utils.CrossoverSelector;
import utils.MutationSelector;
import utils.ProblemSelector;
import utils.PseudoRandomGenerator;
import utils.SelectionSelector;

public class Runner {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {

		Algorithm algorithm;
		Problem problem;
		Operator crossover;
		Operator mutation;
		Operator selection;

		HashMap parameters;

		String problemName = "ndtlz1";
		String algorithmName = "SMSEMOA_IGD";
		String crossoverName = "SBX";
		String mutationName = "PM";
		String selectionName = "Random";
		String optimize = "min";
		String fileName = "m3_100000ref.csv";   // name of the file of the reference points used in IGD-based SMS-EMOA
		String solFileName = "";
		boolean readFile = false;


		int populationSize = 20;
		int numberOfIterations = 100000;
		int numberOfRuns = 1;

		int numberOfObjectives = 3;
		int numberOfVariables = 0 + numberOfObjectives - 1;
		int numberOfConstraints = 0;


		double crossoverProbability = 1.0;
		double eta_c = 20.0;

		double mutationProbability = 1.0;
		double eta_m = 20.0;

		int numberOfPositionVariables = -1;
		int numberOfDistanceVariables = -1;

		if((args.length%2 == 0) && (args.length > 0)) {
			for(int i = 0; i < args.length; i++) {
				if(args[i].equalsIgnoreCase("-pr")) {
					problemName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-al")) {
					algorithmName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-cr")) {
					crossoverName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-mu")) {
					mutationName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-se")) {
					selectionName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-op")) {
					optimize = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-pop")) {
					populationSize = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-ite")) {
					numberOfIterations = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-run")) {
					numberOfRuns = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-obj")) {
					numberOfObjectives = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-var")) {
					numberOfVariables = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-con")) {
					numberOfConstraints = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-pc")) {
					crossoverProbability = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-ec")) {
					eta_c = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-pm")) {
					mutationProbability = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-em")) {
					eta_m = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-fn")) {
					fileName = args[i + 1];
					readFile = true;
				} else if(args[i].equalsIgnoreCase("-sfn")) {
					solFileName = args[i + 1];
					readFile = true;
				} else if(args[i].equalsIgnoreCase("-pos")) {
					numberOfPositionVariables = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-dis")) {
					numberOfDistanceVariables = Integer.parseInt(args[i + 1]);
				}
			}
		}

		PseudoRandomGenerator.setSeed(numberOfRuns+1);

		parameters = new HashMap();
		parameters.put("numberOfVariables", numberOfVariables);
		parameters.put("numberOfObjectives", numberOfObjectives);
		parameters.put("numberOfConstraints", numberOfConstraints);
		if(numberOfPositionVariables != -1) parameters.put("numberOfPositionVariables", numberOfPositionVariables);
		if(numberOfDistanceVariables != -1) parameters.put("numberOfDistanceVariables", numberOfDistanceVariables);
		problem =  (Problem)ProblemSelector.getProblem(problemName, parameters);

		if(problem == null) {
			System.out.println("problem is null! (Not matching)");
			System.exit(-1);
		}

		algorithm = (Algorithm)AlgorithmSelector.getAlgorithm(algorithmName, problem);

//		algorithm.addInputParameter("populationSize", populationSize);
		algorithm.addInputParameter("sizeOfPopulation", populationSize);
//		numberOfIterations = Math.min(populationSize * numberOfGenerations, numberOfIterations);
		algorithm.addInputParameter("numberOfIterations", numberOfIterations);
		algorithm.addInputParameter("fileName", fileName);
		algorithm.addInputParameter("numberOfRuns", numberOfRuns);
		if(!solFileName.equalsIgnoreCase("")) {
			algorithm.addInputParameter("solsFileName", solFileName);
			algorithm.addInputParameter("readSolsFile", readFile);
		}
		if(optimize.equalsIgnoreCase("min")) {
			algorithm.addInputParameter("minimize", true);
		} else if(optimize.equalsIgnoreCase("max")){
			algorithm.addInputParameter("minimize", false);
		}

		parameters = new HashMap();
		parameters.put("probability", crossoverProbability);
		parameters.put("distributionIndex", eta_c);
		crossover = (Operator)CrossoverSelector.getCrossover(crossoverName, parameters);
		algorithm.addOperator("crossover", crossover);


		int nVars = problem.getNumberOfVariables();
		parameters = new HashMap();
		parameters.put("probability", mutationProbability / nVars);
		parameters.put("distributionIndex", eta_m);
		mutation = (Operator)MutationSelector.getMutation(mutationName, parameters);
		algorithm.addOperator("mutation", mutation);

		parameters = null;
		selection = (Operator)SelectionSelector.getSelection(selectionName, parameters);
		algorithm.addOperator("selection", selection);

		File file = new File("FUN_r" + numberOfRuns + "_m" + numberOfObjectives + ".csv");
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		algorithm.setting();

		long start = System.currentTimeMillis();
		ArrayList<Solution> solutionSet = algorithm.execute();
		long end = System.currentTimeMillis();
		System.out.println((end - start) + "ms");

		for(int i = 0; i < solutionSet.size(); i++) {
			for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
				//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
				pw.print(solutionSet.get(i).getObjective(j));
				if(j < solutionSet.get(i).getObjectives().length - 1)
					pw.print(",");
			}
			pw.println();
		}
		pw.close();

		file = new File("FUN_r" + numberOfRuns + "_m" + numberOfObjectives + "_ss.csv");
		pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

			for(int i = 0; i < solutionSet.size(); i++) {
				for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet.get(i).getObjective(j));
					if(j < solutionSet.get(i).getObjectives().length - 1)
						pw.print(" ");
				}
				pw.println();
			}

		pw.close();

		file = new File("VAR_r" + numberOfRuns + "_m" + numberOfObjectives + ".csv");
		pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

			for(int i = 0; i < solutionSet.size(); i++) {
				for(int j = 0; j < solutionSet.get(i).getVariables().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet.get(i).getVariable(j));
					if(j < solutionSet.get(i).getVariables().length - 1)
						pw.print(",");
				}
				pw.println();
			}

		pw.close();

		file = new File("ExperimentalDetail_r" + numberOfRuns + ".csv");
		pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
		pw.println("computational time,"+(end - start));
		pw.close();

	}//main
}//class
