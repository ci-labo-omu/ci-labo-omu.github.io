package operator.selection;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import core.Operator;
import core.Problem;
import core.Solution;
import emoa.ga.GeneticAlgorithm;
import utils.PseudoRandomGenerator;
import utils.comparator.ObjectiveComparator;
import utils.comparator.ParetoComparator;
import utils.indicator.IHSO;

public class SolutionSelection extends GeneticAlgorithm {

	int numberOfObjectives_;
	int sizeOfPopulation_;
	Operator selection_;
	boolean minimize_;
	boolean readSolsFile_;
	String solsFileName_;
	double[] referencePoint_;
	double refValue_;

	public SolutionSelection(Problem problem) {
		super(problem);
	}

	@Override
	public void setting() {
		selection_ = this.getOperator("selection");
		minimize_ = (Boolean)this.getInputParameter("minimize");
		sizeOfPopulation_ = (Integer)this.getInputParameter("sizeOfPopulation");
		ParetoComparator.setOptimize("max");
		if(minimize_) ParetoComparator.setOptimize("min");
		this.numberOfObjectives_ = this.problem_.getNumberOfObjectives();
		this.readSolsFile_ = (Boolean)this.getInputParameter("readSolsFile");
		if(this.readSolsFile_) solsFileName_ = (String)this.getInputParameter("solsFileName");
		this.refValue_ = (Double)this.getInputParameter("HVreference");
	}

	@Override
	public void initialize() throws ClassNotFoundException {
		if(!readSolsFile_) {
			System.err.println("Input the name of solution file!!");
			System.exit(-1);
		} else {
			try {
				FileReader fr = new FileReader(solsFileName_);
				BufferedReader br = new BufferedReader(fr);
				String temp;
				ArrayList<ArrayList<Double>> f = new ArrayList<>();
				while((temp = br.readLine()) != null){
					String[] array = temp.split(" ");
					ArrayList<Double> refPoint = new ArrayList<>();
					for(int j = 0; j < array.length; j++) refPoint.add(Double.parseDouble(array[j]));
					f.add(refPoint);
				}
				br.close();
				fr.close();

				ArrayList<Double> vars;
				for(int i = 0; i < f.size(); i++) {
					vars = new ArrayList<>();
//					for(int j = 0; j < problem_.getNumberOfVariables(); j++) vars.add(0.0);
					Solution s = new Solution(vars, f.get(i), problem_.getSolutionType());
					population_.add(s);
				}
			} catch (IOException e) {
				System.err.println(e);
				System.exit(-1);
			}
		}
		referencePoint_ = new double[numberOfObjectives_];
		for(int i = 0; i < numberOfObjectives_; i++) referencePoint_[i] = refValue_;
	}

	@Override
	public void recombination() throws ClassNotFoundException {}

	@Override
	public void updatePopulation() throws ClassNotFoundException {
		ArrayList<Solution> sols = new ArrayList<>();
		if(population_.size() == 0) {
			System.err.println("No solution!!");
			System.exit(-1);
		}
		if(population_.size() == 1) nextPopulation_ = population_;
		for(Solution s: population_) sols.add(new Solution(s));
		if(minimize_) sols = convertToMinus(referencePoint_, sols);

		ArrayList<Solution> strong_dominate = new ArrayList<>();
		for(int i = 0, size = sols.size(); i < size; i++) {
			if(strongDominate(referencePoint_, sols.get(i))) strong_dominate.add(sols.get(i));
		}
		if(strong_dominate.size() == 0) {
			System.out.println("Any solution has not HV contribution!!");
			System.exit(-1);
		}
		sols = strong_dominate;

		for(int i = 0, size = sols.size(); i < size; i++) {
			for(int j = i + 1; j < size; j++) {
				if(duplicate(sols.get(i), sols.get(j))) {
					sols.remove(i);
					sols.remove(j-1);
					size = sols.size();
				}
			}
		}
		if(sols.size() == 0) {
			System.out.println("All solutions are duplicate with each other!!");
			System.exit(-1);
		}

		for(int i = 0, size = sols.size(); i < size; i++) sols.get(i).setIndividualNumber(i);
		Collections.sort(sols, new ObjectiveComparator(0, false));
		double maxCont = -Double.MAX_VALUE;
		int index = -1;
		double contribution = 0.0;
		ArrayList<Integer> indexArray = new ArrayList<>();
		ArrayList<Solution> temp = new ArrayList<>();
		int numberOfSols = sizeOfPopulation_;
		if(numberOfSols > sols.size()) {
			nextPopulation_ = sols;
			if(minimize_) nextPopulation_ = convertToMinus(referencePoint_, nextPopulation_);
			return;
		}
		while(nextPopulation_.size() < numberOfSols) {
			for(int i = 0;i < sols.size(); i++) {
				IHSO ihso = null;
				if(nextPopulation_.size() == 0) {
					ArrayList<Double> f = new ArrayList<>();
					for(int obj = 0; obj < referencePoint_.length; obj++) f.add(referencePoint_[obj]-1.0);
					ArrayList<Double> x = new ArrayList<>();
					Solution s = new Solution(x, f, problem_.getSolutionType());
					temp.add(s);
					ihso = new IHSO(temp, referencePoint_, sols.get(i));
					contribution = ihso.execute();
				} else {
					ihso = new IHSO(nextPopulation_, referencePoint_, sols.get(i));
					contribution = ihso.execute();
				}
				ihso = null;
				if(contribution > maxCont) {
					maxCont = contribution;
					index = i;
					indexArray.clear();
					indexArray.add(i);
				} else if(contribution == maxCont) {
					indexArray.add(i);
				}
			}
			index = indexArray.get(PseudoRandomGenerator.randInt(0, indexArray.size()));
			nextPopulation_.add(new Solution(sols.get(index)));
			sols.remove(index);
			indexArray.clear();
			maxCont = -Double.MAX_VALUE;
			index = -1;
		}
		if(minimize_) nextPopulation_ = convertToMinus(referencePoint_, nextPopulation_);
		System.out.println("nextPopulation_.size: " + nextPopulation_.size());
	}

	@Override
	public boolean isTerminated(int t) {
		return false;
	}

	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {
		population_ = new ArrayList<Solution>();
		nextPopulation_ = new ArrayList<Solution>();
		initialize();
		updatePopulation();
		return nextPopulation_;
	}


	ArrayList<Solution> convertToMinus(ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < solutionSet.get(0).getObjectives().length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		return sols;
	}


	ArrayList<Solution> convertToMinus(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		assert(r.length == solutionSet.get(0).getObjectives().length);
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < r.length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		for(int i = 0; i < r.length; i++) {
			r[i] *= -1.0;
		}
		return sols;
	}


	static boolean strongDominate(double[] r, Solution sol) {
		boolean dominate = true;
		for(int m = 0, numberOfObjectives = r.length; m < numberOfObjectives; m++) {
			if(sol.getObjective(m) <= r[m]) {
				dominate = false;
				break;
			}
		}
		return dominate;
	}


	static boolean duplicate(Solution sol1, Solution sol2) {
		boolean duplicated = true;
		assert(sol1.getObjectives().length == sol2.getObjectives().length);
		for(int m = 0, numberOfObjectives = sol1.getObjectives().length; m < numberOfObjectives; m++) {
			if(sol1.getObjective(m) != sol2.getObjective(m)) {
				duplicated = false;
				break;
			}
		}
		return duplicated;
	}

}
