package operator.selection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class SimilalityBasedSelection extends Operator{

	private Comparator comparator_;
	public boolean firstSelection_ = true;//this shows 1st or 2nd parent selection.
	public double[] center_;
	private Solution s1_;
	private int alpha_ = 10;
	private int beta_ = 10;


	public SimilalityBasedSelection(HashMap<String, Object> parameters) {
		super(parameters);
	}


	@Override
	public Object execute(Object object) throws ClassNotFoundException {
		ArrayList<Solution> solutionSet = (ArrayList<Solution>)object;
		Solution s;
		ArrayList<Solution> sols = new ArrayList<>();
		if(firstSelection_) {
			for(int i = 0; i < alpha_; i++)
				sols.add(solutionSet.get(PseudoRandomGenerator.randInt(0, solutionSet.size())));
			center_ = calculateCenter(sols);
			s = getMaxDistSolution(sols, center_);
			s1_ = new Solution(s);
			firstSelection_ = false;
		} else {
			for(int i = 0; i < beta_; i++)
				sols.add(solutionSet.get(PseudoRandomGenerator.randInt(0, solutionSet.size())));
			s = getMinDistSolution(sols, s1_);
			firstSelection_ = true;
		}
		return s;
	}


	public double[] calculateCenter(ArrayList<Solution> sols) {
		double[] center = new double[sols.get(0).getNumberOfObjectives()];
		double sum = 0.0;
		for(int ob = 0; ob < center.length; ob++) {
			sum = 0.0;
			for(int id = 0; id < sols.size(); id++) sum += sols.get(id).getObjective(ob);
			center[ob] = sum / (double)sols.size();
		}
		return center;
	}


	public Solution getMaxDistSolution(ArrayList<Solution> sols, double[] c) {
		Solution s = new Solution(sols.get(0));
		double maxDist = calculateDistance(s, c);
		if(sols.size() == 1) return s;
		double dist;
		for(int id = 0; id < sols.size(); id++) {
			dist = calculateDistance(sols.get(id), c);
			if(maxDist < dist) {
				maxDist = dist;
				s = new Solution(sols.get(id));
			}
		}
		return s;
	}


	public Solution getMinDistSolution(ArrayList<Solution> sols, Solution s1) {
		Solution s = new Solution(sols.get(0));
		double minDist = calculateDistance(s, s1);
		if(sols.size() == 1) return s;
		double dist;
		for(int id = 0; id < sols.size(); id++) {
			dist = calculateDistance(sols.get(id), s1);
			if(minDist > dist) {
				minDist = dist;
				s = new Solution(sols.get(id));
			}
		}
		return s;
	}


	public double calculateDistance(Solution s, double[] c) {
		double dist = 0.0;
		for(int ob = 0; ob < c.length; ob++)
			dist += (s.getObjective(ob) - c[ob]) * (s.getObjective(ob) - c[ob]);
		dist = Math.sqrt(dist);
		return dist;
	}


	public double calculateDistance(Solution s, Solution s1) {
		double dist = 0.0;
		for(int ob = 0; ob < s1.getNumberOfObjectives(); ob++)
			dist += (s.getObjective(ob) - s1.getObjective(ob)) * (s.getObjective(ob) - s1.getObjective(ob));
		dist = Math.sqrt(dist);
		return dist;
	}

}
