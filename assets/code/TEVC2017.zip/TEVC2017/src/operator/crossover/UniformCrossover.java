package operator.crossover;

import java.util.ArrayList;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class UniformCrossover extends Operator {

	double crossoverProbability_ = 0.8;

	public UniformCrossover(HashMap<String, Object> parameters) {
		super(parameters);
		if (parameters.get("probability") != null)
			crossoverProbability_ = (Double) parameters.get("probability");
		this.nNecessarySols_ = 2;
	}

	@Override
	public Object execute(Object object) throws ClassNotFoundException {

		ArrayList<Solution> parents = (ArrayList<Solution>)object;

		if(parents.size() < this.nNecessarySols_)
			System.exit(-1);

		Solution s1 = new Solution(parents.get(0));
		Solution s2 = new Solution(parents.get(1));

		if((s1.getSolutionType() != "Binary") || (s2.getSolutionType() != "Binary")) {
			System.err.println("Solution type is Binary!!!");
			System.exit(-1);
		}

		ArrayList<Solution> children = new ArrayList<Solution>(2);

		if(PseudoRandomGenerator.randDouble() < crossoverProbability_) {
			Solution child1 = new Solution(s1.getVariables().length, s1.getObjectives().length, s1.getSolutionType());
			Solution child2 = new Solution(s2.getVariables().length, s2.getObjectives().length, s2.getSolutionType());

			for(int i = 0, n = s1.getVariables().length; i < n; i++) {
				if(PseudoRandomGenerator.randDouble() < 0.5) {
					child1.setVariable(i, s1.getVariable(i));
					child2.setVariable(i, s2.getVariable(i));
				} else {
					child1.setVariable(i, s2.getVariable(i));
					child2.setVariable(i, s1.getVariable(i));
				}
			}
			children.add(child1);
			children.add(child2);
		} else {
			children.add(s1);
			children.add(s2);
		}
		return children;
	}

}
