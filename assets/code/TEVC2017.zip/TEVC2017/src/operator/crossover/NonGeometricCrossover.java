package operator.crossover;

import java.util.ArrayList;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class NonGeometricCrossover extends Operator {

	double crossoverProbability_ = 0.8;
	double BitFlipProbability_ = 2.0 / 500.0;
	Operator uc_;

	public NonGeometricCrossover(HashMap<String, Object> parameters) {
		super(parameters);
		if (parameters.get("probability") != null)
			crossoverProbability_ = (Double) parameters.get("probability");
		uc_ = new UniformCrossover(parameters);
		this.nNecessarySols_ = 2;
	}


	@Override
	public Object execute(Object object) throws ClassNotFoundException {

		//do Uniform crossover or Non-geometric crossover randomly.
		if(PseudoRandomGenerator.randDouble()<=0.5)
			return uc_.execute(object);

		ArrayList<Solution> parents = (ArrayList<Solution>)object;

		if(parents.size() < this.nNecessarySols_)
			System.exit(-1);

		Solution s1 = new Solution(parents.get(0));
		Solution s2 = new Solution(parents.get(1));

		if((s1.getSolutionType() != "Binary") || (s2.getSolutionType() != "Binary")) {
			System.err.println("Solution type is Binary!!!");
			System.exit(-1);
		}

		ArrayList<Solution> children = new ArrayList<Solution>(1);

		if(PseudoRandomGenerator.randDouble() > crossoverProbability_) {
			children.add(new Solution(parents.get(PseudoRandomGenerator.randInt(0, 2))));
			return children;
		}

		Solution child1 = new Solution(s1.getVariables().length, s1.getObjectives().length, s1.getSolutionType());

		for(int i = 0, n = s1.getVariables().length; i < n; i++) {
			if(s1.getVariable(i) == s2.getVariable(i)) {
				if(PseudoRandomGenerator.randDouble() <= BitFlipProbability_){
					child1.setVariable(i, s2.getVariable(i));
				} else {
					child1.setVariable(i, s1.getVariable(i));
				}
			} else {
				child1.setVariable(i, s1.getVariable(i));
			}
		}
		children.add(child1);

		return children;
	}


}
