package operator.crossover;

import java.util.ArrayList;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class DEOperator extends Operator {


	double crossoverProbability_ = 0.9;
	double CR_ = 1.0;
	double F_ = 0.5;


	public DEOperator(HashMap<String, Object> parameters) {
		super(parameters);

		if (parameters.get("probability") != null)
			crossoverProbability_ = (Double) parameters.get("probability");
		if (parameters.get("F") != null)
			F_ = (Double) parameters.get("F");
		if (parameters.get("CR") != null)
			CR_ = (Double) parameters.get("CR");

		this.nNecessarySols_ = 3;
	}

	@Override
	public Object execute(Object object) throws ClassNotFoundException {
		ArrayList<Solution> parents = (ArrayList<Solution>)object;
		if(parents.size() < 3) System.exit(-1);
		Solution s1 = new Solution(parents.get(0));
		Solution s2 = new Solution(parents.get(1));
		Solution s3 = new Solution(parents.get(2));

		if((s1.getSolutionType() != "Real") || (s2.getSolutionType() != "Real") || (s3.getSolutionType() != "Real")) {
			System.err.println("Solution type is Real!!!");
			System.exit(-1);
		}
		ArrayList<Solution> children = new ArrayList<>();
		if(PseudoRandomGenerator.randDouble() < this.crossoverProbability_) {
			Solution child = new Solution(s1.getVariables().length, s1.getObjectives().length, s1.getSolutionType());
			for(int i = 0, length = child.getVariables().length; i < length; i++) {
				child.setLowerbound(i, s1.getLowerbound(i));
				child.setUpperbound(i, s1.getUpperbound(i));
			}
			for(int var = 0, length = s1.getNumberOfVariables(); var < length; var++) {
				if(PseudoRandomGenerator.randDouble() < 1.0 - this.CR_) {
					child.setVariable(var, s1.getVariable(var));
				} else {
					double value = s1.getVariable(var) + this.F_ * (s2.getVariable(var) - s3.getVariable(var));
					if(value < child.getLowerbound(var) || child.getUpperbound(var) < value)
						value = PseudoRandomGenerator.randDouble(child.getLowerbound(var), child.getUpperbound(var));
					child.setVariable(var, value);
				}
			}
			children.add(child);
			return children;
		} else {
			children.add(new Solution(parents.get(PseudoRandomGenerator.randInt(0, 3))));
			return children;
		}
	}

}
