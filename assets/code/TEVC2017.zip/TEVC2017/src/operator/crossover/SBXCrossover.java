package operator.crossover;

import java.util.ArrayList;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class SBXCrossover extends Operator{

	double crossoverProbability_ = 0.9;
	double distributionIndex_ = 30.0;

	private static final double EPS = 1.0e-14;

	//Constructor
	public SBXCrossover(HashMap<String, Object> parameters) {
		super(parameters);

		if (parameters.get("probability") != null)
			crossoverProbability_ = (Double) parameters.get("probability");
		if (parameters.get("distributionIndex") != null)
			distributionIndex_    = (Double) parameters.get("distributionIndex");
		this.nNecessarySols_ = 2;
	}


	@Override
	public Object execute(Object object) {

		//System.out.println(crossoverProbability_);
		//System.out.println(EPS);


		ArrayList<Solution> parents = (ArrayList<Solution>)object;

		if(parents.size() < this.nNecessarySols_)
			System.exit(-1);

		Solution s1 = new Solution(parents.get(0));
		Solution s2 = new Solution(parents.get(1));

		if((s1.getSolutionType() != "Real") || (s2.getSolutionType() != "Real")) {
			System.err.println("Solution type is Real!!!");
			System.exit(-1);
		}

		ArrayList<Solution> children = new ArrayList<Solution>(2);
		double alpha;
		double beta;
		double beta_q;
		double u;
		double p1;
		double p2;
		double c1;
		double c2;
		double eta = this.distributionIndex_ + 1.0;

		if(PseudoRandomGenerator.randDouble() < crossoverProbability_) {
			Solution child1 = new Solution(s1.getVariables().length, s1.getObjectives().length, s1.getSolutionType());
			Solution child2 = new Solution(s2.getVariables().length, s2.getObjectives().length, s2.getSolutionType());

			for(int i = 0, length = child1.getVariables().length; i < length; i++) {
				child1.setLowerbound(i, s1.getLowerbound(i));
				child1.setUpperbound(i, s1.getUpperbound(i));
				child2.setLowerbound(i, s2.getLowerbound(i));
				child2.setUpperbound(i, s2.getUpperbound(i));
			}

			for(int i = 0, length = s1.getVariables().length; i < length; i++) {
				if(PseudoRandomGenerator.randDouble() < 0.5) {
					if(Math.abs(s1.getVariable(i) - s2.getVariable(i)) > EPS) {

						if(s1.getVariable(i) < s2.getVariable(i)) {
							p1 = s1.getVariable(i);
							p2 = s2.getVariable(i);
						} else {
							p2 = s1.getVariable(i);
							p1 = s2.getVariable(i);
						}

						double lb = s1.getLowerbound(i);
						double ub = s1.getUpperbound(i);

						beta = 1.0 + (2.0 * (p1 - lb) / (p2 - p1));
						alpha = 2.0 - (1.0 / Math.pow(beta, eta));
						u = PseudoRandomGenerator.randDouble();
						if(u <= (1.0 / alpha)) {
							beta_q = Math.pow(u * alpha, 1.0 / eta);
						} else {
							beta_q = Math.pow((1.0 / (2.0 - u * alpha)), (1.0 / eta));
						}
						c1 = 0.5 * ((p1 + p2) - beta_q * (p2 - p1));

						beta = 1.0 + (2.0 * (ub - p2) / (p2 - p1));
						alpha = 2.0 - (1.0 / Math.pow(beta, eta));
						u = PseudoRandomGenerator.randDouble();
						if(u <= (1.0 / alpha)) {
							beta_q = Math.pow(u * alpha, 1.0 / eta);
						} else {
							beta_q = Math.pow((1.0 / (2.0 - u * alpha)), (1.0 / eta));
						}
						c2 = 0.5 * ((p1 + p2) + beta_q * (p2 - p1));

						if (c1<lb)
							c1=lb;

						if (c2<lb)
							c2=lb;

						if (c1>ub)
							c1=ub;

						if (c2>ub)
							c2=ub;

						if (PseudoRandomGenerator.randDouble()<0.5) {
							child1.setVariable(i, c2) ;
							child2.setVariable(i, c1) ;
						} else {
							child1.setVariable(i, c1) ;
							child2.setVariable(i, c2) ;
						} // if

					} else {
						child1.setVariable(i, s1.getVariable(i));
						child2.setVariable(i, s2.getVariable(i));
					}
				} else {
					child1.setVariable(i, s2.getVariable(i));
					child2.setVariable(i, s1.getVariable(i));
				}
			}

			children.add(child1);
			children.add(child2);

		} else {
			children.add(s1);
			children.add(s2);
		}

		return children;
	}

}

