classdef AlphaIsE_14 < PROBLEM
% <problem> <FeasibleRegion>

%------------------------------- Reference --------------------------------
% H. Ishibuchi, T. Matsumoto, N. Masuyama, and Y. Nojima, "Many-Objective Problems Are Not Always
% Difficult for Pareto Dominance-Based Evolutionary Algorithms", ECAI 2020 (Under Review).
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        %% Initialization
        function obj = AlphaIsE_14()
            if isempty(obj.Global.M)
                obj.Global.M = 3;
            end
            if isempty(obj.Global.D)
                obj.Global.D = obj.Global.M + 4;
            end
            obj.Global.lower    = zeros(1,obj.Global.D);
            obj.Global.upper    = ones(1,obj.Global.D);
            obj.Global.encoding = 'real';
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,PopDec)
            [N, D]  = size(PopDec);
            M      = obj.Global.M;
            % DTLZ1 function
            g      = 100 * (D - M + 1 + sum((PopDec(:, M : end) - 0.5) .^ 2 ...
             -cos(20 .* pi .* (PopDec(:, M : end) - 0.5)),2));

            h = fliplr(cumprod([ones(size(g, 1), 1),cos(PopDec(:, 1 : M-1) * pi / 2)], 2))...
            .* [ones(size(g, 1), 1),sin(PopDec(:, M-1 : -1 : 1) * pi / 2)];
            PopObj = (h .^ 2) .* repmat(1 + g, 1, M) + 1e-14 * repmat(g, 1, M);
        end
        function PopObj = CalObjBasedOnDistance(obj,PopDec, g)
            [N, D]  = size(PopDec);
            M      = obj.Global.M;

            h = fliplr(cumprod([ones(size(g, 1), 1),cos(PopDec(:, 1 : M-1) * pi / 2)], 2))...
            .* [ones(size(g, 1), 1),sin(PopDec(:, M-1 : -1 : 1) * pi / 2)];
            PopObj = (h .^ 2) .* repmat(1 + g, 1, M) + 1e-14 * repmat(g, 1, M);
        end
        %% Sample reference points on Pareto front
        function P = PF(obj,N)
            P = ReferencePoints(N,obj.Global.M);
        end
    end
end