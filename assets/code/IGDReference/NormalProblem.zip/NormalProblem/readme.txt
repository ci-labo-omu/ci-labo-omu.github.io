Before calculating IGD, you should normalize objective vectors
using the ideal point z_i and the nadir point z_n so that they 
are normalized as z_i = (0, 0, ..., 0) and z_n = (1, 1, ..., 1).

Problem and coressponding reference set are shown below.
Problem - Reference set
DTLZ1 - simplex
DTLZ2 - sphere
DTLZ3 - sphere
DTLZ4 - sphere
WFG1 - WFG1(all non-dominated solutions in the experiment)
WFG2 - WFG2(all non-dominated solutions in the experiment)
WFG3 - WFG3(all non-dominated solutions in the experiment)
WFG4 - sphere
WFG5 - sphere
WFG6 - sphere
WFG7 - sphere
WFG8 - sphere
WFG9 - sphere
